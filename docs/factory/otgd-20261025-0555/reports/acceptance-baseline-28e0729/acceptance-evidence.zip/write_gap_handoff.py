from pathlib import Path
import json,collections,datetime,hashlib
O=Path('/workspace/scratch/otgd-20261025-0555-live/verification');R=Path('/workspace/One-The-Go-Detection')
v=json.loads((O/'case-reconciliation.json').read_text());rows=v['rows']
# Only demonstrated/council-confirmed functional defects belong in this list.
confirmed=[
 ('OAuth endpoint pinning','D009v1','correction-auth.md',['OTGD-037-AND-AUTH-001-01','OTGD-037-AND-AUTH-002-02']),
 ('Home/history scientific-state and conditional scope copy','D009v1','correction-product.md',['OTGD-002-AND-DASH-001-01']),
 ('Onboarding conditional research copy','D009v1','correction-product.md',['OTGD-005-AND-ONB-001-01']),
 ('Supplied uncertainty policy presentation','D009v1','correction-product.md',['OTGD-009-MODEL-005-01']),
 ('Destination accessibility focus','D009v1','correction-accessibility.md',[]),
 ('Dark destructive contrast','D009v1','correction-accessibility.md',[]),
 ('Effective reduced motion','D009v1','correction-accessibility.md',[]),
 ('Python native timestamp difference and half-open terminal cutoff','D009v3','correction-native-assertions.md',['OTGD-033-AND-TASK-004-03']),
 ('Conflict authoritative readback preserving pending evidence','D009v3','correction-product.md',['OTGD-029-AND-SYNC-005-01','OTGD-026-AND-CHECK-006-02']),
 ('422 bounded inspectable field reasons','D009v3','correction-product.md',['OTGD-029-AND-SYNC-006-02']),
 ('Truthful privacy retained category receipt/display','D009v4','correction-privacy-raw-ui.md',['OTGD-031-AND-PRIV-004-02','OTGD-031-AND-PRIV-004-03']),
 ('History owner/environment/generation/sort cursor admission','D009v5','correction-history-boundaries.md',['OTGD-028-AND-HIST-002-01']),
 ('Verify every admitted web asset','D009v5','correction-web-assets.md',['OTGD-044-WEBDEP-007-01','OTGD-044-WEBDEP-010-01']),
 ('Preparation UTC versus monotonic consistency','D009v5/v6','participant-author report/source binding pending',['OTGD-039-PAI-008-02']),
]
report_records=[]
for p in sorted((R/'docs/factory/otgd-20261025-0555/reports').glob('correction-*.md')):
 raw=p.read_bytes();report_records.append({'path':str(p.relative_to(R)),'sha256':hashlib.sha256(raw).hexdigest(),'binding':'Current mutable author report only. No frozen replacement acceptance or automatic oldcase status upgrade.'})
residual=[{k:r.get(k) for k in ['case_id','spec_id','adjudication_state','status','remaining_category','canonical_path','canonical_sha256','source_assertion_refs','unproven_clauses','scope_judgment']} for r in rows if r['status']!='PASS']
result={'candidate':v['binding']['candidate'],'scope':'Old candidate28 historical per-case residuals, not a count of bugs or an order to add tests. No replacement gate/source admission.','confirmed_functional_groups':[dict(zip(['group','decision','author_report','affected_example_cases'],r)) for r in confirmed],'replacement_author_report_inventory':report_records,'historical_case_residuals':residual,'audit_pending_cases':[r['case_id'] for r in rows if r['adjudication_state']=='AUDIT_PENDING'],'interpretation':'Only confirmed_functional_groups are corroborated functional defects. Other residuals can be source/assertion composition limits, missing execution bindings, OS/physical/cloud/owner prerequisites or pending audit. Generic related-review tags do not prove a broad owner criterion has a defect. Exact-frozen-source review can combine independently meaningful assertions where it proves all clauses; no redundant implementation-mirroring tests requested. PM ends round1 after currently assigned repairs, then freezes/gates/rereviews; no automatic round extension.'}
(O/'software-gap-handoff.json').write_text(json.dumps(result,indent=2)+'\n')
t='''# Bounded correction and evidence handoff

Candidate `28e07295cb37bb9dcaaac82cc8fc846eb89006a6` remains the historical audited source. This handoff does **not** label every PARTIAL row a software defect or require another test for each literal scenario. Shared-source composition and meaningful existing assertions can establish a criterion; static implementation-shaped tests add no independent evidence. Broad owner/scientific/deployment/tabletop/contact criteria are not classified as software defects from related OAuth/UI tags.

## Corroborated functional repair groups

'''
for group,d,report,ids in confirmed:t+=f'- {group} — {d}; author evidence `{report}`. Replacement source execution/review still required.\n'
t+='''
## Bounded assertion supplements already assigned or authored

- Evaluation: descriptor mutation; sparse one-class/singleton versus supported participant subgroup accounting; minimum-defined bootstrap draw boundary; future-input rejection on invalid rows. Current author reports describe9new cases/179focused and PM22invalid-row checks. They remain replacement-source focused evidence.
- Native: retained wrong/correct ledger,80msdispatchdelay,both equal-time orders/ties and actual Python reference refusal. Author45host passes do not establish replacement Kotlin/Swift execution. PM separately assigned Swift full-raw-byte/hash and vendor freshness boundary tests; no hardware proof follows.
- Sync/profile: actual409/412comparison,429deadline/bounds/noearlyretry,422safe fields; meaningful measurement-modeP1=80kg→P2=82kg before/after software attempt interruption and new linked check. Product author reports these now authored and360unit passes; no profile production defect was needed. Final source-bound execution remains required.
- Raw/operator/recovery/privacy: author reports meaningful eligible-choice survivor, retired export-authority POST replay,no-storeattachment,combinedbudget overflow; PostgreSQL original-body/digest/version immutability; optical retiredsettlement; configured sealed-resumption capture/model and deniedchangeddependencies; cleanup without reopeningdata; bounded actual privacyreceipt. Client reports originalacceptedreceiptIDoracle,exactrenewalbody/precommittedepoch,actualquarantine/cleanuprender and actualreceipt→parser→JobCard. These supplement the historical partial rows rather than automatically closing their independent external clauses.
- Auth: PM assigned successful callback replay(exchangecount1/noaccountswitch) and3actualHTTP401requests(one refresh, eligible replayonce/originalkey+body). Preserve existing meaningful tests; no production edit without a demonstrated defect and PM assignment.
- Participant: PAI acknowledgment age/pre-attempt boundaries and preparationclock100ms inclusive engineering guard are assigned/authored. PM assigned bounded SALCOL latefirstsubmission/replay,required-versus-permittedmissingchemistry,abandonment+minimumchannel,contradictorymissingreason and initialimport target/authority negatives. Follow current PM write holds. No independently qualified channel/model is created by these tests.

No further unbounded first-round repairs are requested by this handoff. After currently assigned repairs, PM freezes the replacement, runs required gates and obtains six independent rereviews; those decisions may determine whether round2 is necessary.

## Residuals and prerequisites

`case-reconciliation.json` is the authoritative one-row-per-case historical record. `software-gap-handoff.json` retains every non-PASS exact residual under **historical_case_residuals**, without treating its generic category as a bug finding. AUDIT_PENDING is separately identified and cannot be called a missing test. Replacement report hashes are inventoried separately; author passes are not independent/final acceptance.

Actual installedOS/SQLCipher/Keychain/processdeath/VoiceOver/TalkBack/permission/radio/camera behavior; physical instrument/timing/ECG safety and sensor qualification; independent scientific interpretation/study/participant approvals; real cloud restore/deploy/access/cost/contacts/tabletop and store account/listing prerequisites remain distinct. Software tests cannot satisfy them. Source present but unexecuted remains NOT_RUN/PARTIAL, never qualified.
'''
(O/'software-gap-handoff.md').write_text(t)
print('bounded functional groups',len(confirmed),'historical residual rows',len(residual),'audit pending',len(result['audit_pending_cases']))
