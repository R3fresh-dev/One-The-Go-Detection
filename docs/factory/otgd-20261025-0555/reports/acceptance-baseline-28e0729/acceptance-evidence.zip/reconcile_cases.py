from pathlib import Path
import ast,collections,csv,datetime,hashlib,json,re,subprocess,html,xml.etree.ElementTree as ET
R=Path('/workspace/One-The-Go-Detection');X=Path('/workspace/scratch/otgd-20261025-0555-live');O=X/'verification';B=R/'docs/factory/otgd-20261025-0555';C='28e07295cb37bb9dcaaac82cc8fc846eb89006a6';NOW=datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,v): (O/name).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
manifest=json.loads((X/'candidate.json').read_text());inv=json.loads((B/'inventory.json').read_text());assert manifest['candidate_revision']==C
# Read-only candidate identity verification; output goes only outside the frozen checkout.
mismatch=[]
for path,digest in manifest['file_sha256'].items():
 p=R/path
 if not p.is_file() or sha(p)!=digest:mismatch.append(path)
# PM began round1 coordination import after stopping local gates. Read immutable candidate blobs below, never live replacement sources.
blob_cache={}
def read(path):
 path=str(path)
 if path not in blob_cache:blob_cache[path]=subprocess.check_output(['git','show',C+':'+path],cwd=R)
 return blob_cache[path].decode()
def source_sha(path):return hashlib.sha256(read(path).encode()).hexdigest()
tree=subprocess.check_output(['git','rev-parse',C+'^{tree}'],cwd=R,text=True).strip()
binding={'candidate':C,'candidate_tree':tree,'candidate_manifest_sha256':sha(X/'candidate.json'),'working_tree_sha256':manifest['working_tree_sha256'],'captured_at':NOW,'checked_manifest_files':len(manifest['file_sha256']),'live_worktree_manifest_mismatches':mismatch,'source_origin':'immutable git show candidate:path, independently SHA256 checked against frozen manifest for every mapped source','ci_run':40173151613,'ci_merge_commit':'891e5e789e3f8ac114237dc63f21f1960cdc62d0','ci_merge_tree':'9a62a8ae6bffd16394f68ea9147b8d7c5469f169','ci_tree_equivalence_authority':'PM git/API verification, supplied task and live status.md; candidate tree independently read here','local_image':'a266628e1e2d87d83b0152684298e003dd2e44ce0c145ef6985ea690b8263b06','image_limit':'D006v5 reconstructed local source-filesystem/Config equivalence; no original/cloud image provenance','decisions':['D006v5','D007v1','D008v1'],'verifier':'/root/verification; OpenAI gpt-6.1-sol requested by PM; no council signoff'}
assert tree==binding['ci_merge_tree']
xmls=[];observed=[]
for p in sorted((X/'ci-artifacts').rglob('*.xml')):
 root=ET.parse(p).getroot();cases=root.findall('.//testcase')
 if not cases:continue
 entry={'path':str(p),'sha256':sha(p),'cases':len(cases),'bad_cases':sum(any(c.find(t) is not None for t in ('failure','error','skipped')) for c in cases),'origin':'current CI artifact; ZIP digest verified by PM against GitHub; extracted paths checked by PM'};xmls.append(entry)
 for suite in root.iter('testsuite'):
  for c in suite.findall('testcase'):
   observed.append({'artifact':str(p),'artifact_sha256':entry['sha256'],'suite':suite.get('name'),'project_or_host':suite.get('hostname'),'suite_timestamp':suite.get('timestamp'),'classname':c.get('classname',''),'name':c.get('name',''),'status':'FAIL' if any(c.find(t) is not None for t in ('failure','error')) else 'SKIPPED' if c.find('skipped') is not None else 'PASS','time':c.get('time')})
# Actual Android uploaded reports are HTML rather than XML; inspect every named class result.
for p in sorted((X/'ci-artifacts/android-native').rglob('index.html')):
 if 'expo.modules.' not in str(p):continue
 content=p.read_text();classname=p.parent.name
 for tr in re.findall(r'<tr>(.*?)</tr>',content,re.S):
  cells=re.findall(r'<td[^>]*>(.*?)</td>',tr,re.S)
  if len(cells)>=7 and re.search(r'class="success"',tr) and re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*',html.unescape(re.sub('<[^>]+>','',cells[0])).strip()):
   name=html.unescape(re.sub('<[^>]+>','',cells[0])).strip()
   assert cells[2].strip()=='1' and cells[3].strip()=='0' and cells[4].strip()=='0'
   observed.append({'artifact':str(p),'artifact_sha256':sha(p),'suite':'Android testDebugUnitTest','project_or_host':'current CI native/android','classname':classname,'name':name,'status':'PASS','time':cells[5]})
unitlog=X/'ci-job-121108084791.log';unitlines=unitlog.read_text().splitlines();unitsha=sha(unitlog)
checks={};cache={}
def module(p):
 if p not in cache:
  t=read(p);d={}
  if p.endswith('.py'):
   for n in ast.walk(ast.parse(t)):
    if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):
     d[n.name]={'line':n.lineno,'end':n.end_lineno,'body':'\n'.join(t.splitlines()[n.lineno-1:n.end_lineno]),'node':n}
  elif p.endswith('.ts'):
   ms=list(re.finditer(r'\btest(?:\.\w+)?\s*\(\s*([\'\"`])(.+?)\1',t))
   for i,m in enumerate(ms):d[m[2]]={'line':t[:m.start()].count('\n')+1,'body':t[m.start():ms[i+1].start() if i+1<len(ms) else len(t)]}
  else:
   ms=list(re.finditer(r'\b(?:func|fun|void)\s+([A-Za-z_]\w*)\s*\(',t))
   for i,m in enumerate(ms):d[m[1]]={'line':t[:m.start()].count('\n')+1,'body':t[m.start():ms[i+1].start() if i+1<len(ms) else len(t)]}
  cache[p]=(t,d)
 return cache[p]
def lookup(p,name):
 if not (R/p).is_file():return None
 t,d=module(p)
 if name in d:return d[name]
 if name=='executable fixture suite':return {'line':1,'body':t}
 return None
def named_observations(p,name):
 out=[];stem=Path(p).stem
 for e in observed:
  if p.endswith('.py'):
   good=e['classname'].split('.')[-1]==stem and (e['name']==name or e['name'].startswith(name+'['))
  elif p.endswith('.ts'):good=e['classname']==Path(p).name and e['name']==name
  else:good=e['name']==name
  if good:out.append(e)
 # Mobile Node and operational unittest test names are individually visible in raw CI log.
 for number,line in enumerate(unitlines,1):
  if (p.endswith('.ts') and ('✔ '+name+' (' in line)) or (p.startswith('infra/test/') and name+' (' in line and line.rstrip().endswith('... ok')):
   out.append({'artifact':str(unitlog),'artifact_sha256':unitsha,'line':number,'name':name,'classname':p,'status':'PASS','raw_observation':line})
 return out

def check(p,name):
 key=p+'::'+name
 if key in checks:return key
 info=lookup(p,name)
 if not info:
  checks[key]={'path':p,'name':name,'found':False,'execution':[]};return key
 t,d=module(p);body=info['body'];helpers=[]
 if p.endswith('.py') and 'node' in info:
  called={n.func.id for n in ast.walk(info['node']) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)}
  for n in sorted(called):
   if n in d and not n.startswith('test_'):
    helpers.append({'name':n,'line':d[n]['line'],'body':d[n]['body']})
    if n=='assert_forged_history_refused' and 'external_history_pipeline' in d:helpers.append({'name':'external_history_pipeline','line':d['external_history_pipeline']['line'],'body':d['external_history_pipeline']['body']})
 assertions=[]
 for number,line in enumerate(body.splitlines(),info['line']):
  if re.search(r'\bassert\b|\bexpect\s*[.(]|assert\w*\(|XCTAssert|pytest.raises|\brequire\(',line):assertions.append({'line':number,'text':line.strip()})
 for helper in helpers:
  for number,line in enumerate(helper['body'].splitlines(),helper['line']):
   if re.search(r'\bassert\b|pytest.raises|\brequire\(',line):assertions.append({'line':number,'text':line.strip(),'helper':helper['name']})
 checks[key]={'path':p,'name':name,'found':True,'line':info['line'],'file_sha256':source_sha(p),'source_matches_candidate_manifest':manifest['file_sha256'].get(p)==source_sha(p),'body':body,'helpers':helpers,'assertions':assertions,'execution':named_observations(p,name)}
 return key
# Explicit hand-audited replacements supersede old related-symbol guesses.
OV={}
def override(cases,refs):
 for c in cases:OV[c]=refs
E='services/api/tests/test_model_evaluation.py';H='services/api/tests/test_model_evaluation_cardiac.py';G='services/api/tests/test_operator_governance.py';RAW='apps/mobile/e2e/raw-recordings.spec.ts'
override(['OTGD-008-EVAL-007-01'],[(E,'test_external_history_references_remain_unverified_through_pipeline'),(H,'test_external_history_references_remain_unverified_through_pipeline')])
override(['OTGD-008-EVAL-007-02'],[(E,'test_self_asserted_or_extra_approval_fields_do_not_authenticate_history'),('services/api/tests/test_operator_governance.py','test_immutable_submission_three_principals_lifecycle_history_and_revision')])
override(['OTGD-008-EVAL-004-01','OTGD-008-EVAL-004-02','OTGD-008-EVAL-005-02','OTGD-008-EVAL-005-03'],[(E,'test_subgroups_reconcile_all_rows_and_predictive_values_are_prevalence_qualified'),(E,'test_censored_invalid_and_abstaining_rows_stay_in_every_matched_denominator')])
override(['OTGD-008-EVAL-008-01','OTGD-008-EVAL-008-02'],[(E,'test_input_snapshot_uses_bounded_read_and_rejects_nonregular_files'),(E,'test_json_ingestion_is_bounded_duplicate_safe_and_data_only')])
override(['OTGD-019-AND-ALC-001-02','OTGD-019-AND-ALC-004-02'],[(G,'test_alcohol_configuration_and_calibration_expiry_boundary_preserves_history'),(G,'test_alcohol_current_dependencies_do_not_manufacture_an_available_adapter'),(G,'test_alcohol_expiry_between_contract_grant_and_start_rejects_cached_authority'),('apps/mobile/tests/acquisition.test.ts','a start-time registry dependency refusal after a hypothetical breath grant preserves its authoritative reason and never acquires concentration')])
override(['OTGD-019-AND-ALC-002-01','OTGD-019-AND-ALC-002-02','OTGD-019-AND-ALC-003-01','OTGD-019-AND-ALC-006-02'],[(RAW,'alcohol qualifiers retain zero, low, censored, invalid and simulated evidence without clearance from history through result and detail'),(RAW,'alcohol copy remains accurate for measurement, guest and admitted research contexts')])
override(['OTGD-036-AND-SET-003-01','OTGD-036-AND-SET-003-02','OTGD-036-AND-SET-007-02'],[(RAW,'Settings reads denied, restricted, undetermined and failed camera status without prompting and opens OS settings only explicitly'),(RAW,'Settings ignores out-of-order and unmounted camera reads and replaces stale account and generation observations')])
override(['OTGD-047-STORE-003-02','OTGD-015-CLOUD-DEP-002-02'],[('infra/test/test_provenance.py','test_default_live_verification_requires_container_runtime_for_every_target'),('infra/test/test_provenance.py','test_default_gate_file_and_owned_client_reject_base_only_evidence'),('infra/test/test_provenance.py','test_platform_build_rejects_base_only_evidence_before_signing_or_docker'),('infra/test/test_provenance.py','test_serverless_admission_rejects_base_only_evidence_before_cloud_operations')])
K='apps/mobile/modules/reaction-task/android/src/test/java/expo/modules/otgdreaction/ReactionCoreTest.kt';S='apps/mobile/modules/reaction-task/tests/swift/ReactionCoreTests.swift'
override(['OTGD-033-AND-TASK-002-01'],[(K,'frozenLiteralSchedulesAndHashes'),(S,'testFrozenLiteralSchedulesAndHashes')])
override(['OTGD-033-AND-TASK-004-01','OTGD-033-AND-TASK-004-02','OTGD-033-AND-TASK-004-03','OTGD-033-AND-TASK-004-04'],[(K,'allLiteralTrialBoundaryVectors'),(S,'testAllLiteralTrialBoundaryVectors'),(K,'aggregatesPracticeExclusionAndNullableNoResponseFeatures'),(S,'testAggregatesAndPracticeExclusion')])
override(['OTGD-033-AND-TASK-005-01','OTGD-033-AND-TASK-005-02'],[(K,'aggregatesPracticeExclusionAndNullableNoResponseFeatures'),(S,'testAggregatesAndPracticeExclusion')])
override(['OTGD-033-AND-TASK-008-03'],[(K,'quantilesAndDevelopmentBudgets'),(K,'terminalDrainOverflowAndPendingCancellation'),(S,'testQuantileBudgetsDrainAndTerminalOnce')])
# Selected complete software-only cases were compared clause-by-clause against source and current named observations.
PASS={'OTGD-008-EVAL-007-01': 'Exact caller references retained in complete reproduced CLI evidence and full/HR custody; authenticity/history/authority flags false at emitted contract locations, all current named parameter cases pass. This is software handling of unverified references, not genuine external approval.', 'OTGD-008-EVAL-004-01':'Each of six STRATA dimensions explicitly compares category set/session identities/count totals to its partition for each variant; current named test passes. This closes row reconciliation only, not scientific generalization.', 'OTGD-019-AND-ALC-006-02':'Actual ResultScreen reached via History plus detail for low/censored values; current two-viewport named component cases explicitly reject positive driving/legal-clearance patterns. No instrument qualification inferred.'}
PASS.update({'OTGD-033-AND-TASK-002-01':'Actual Kotlin/Swift suites both compare every literal66-trial schedule index/phase/stimulus/onset/interval and schedule/configuration hash for frozen seeds against the identical shared golden. Pure schedule parity only; physical presentation and native OS integration are not claimed.', 'OTGD-033-AND-TASK-004-02':'Both actual native suites assert anticipatory disposition, omitted trial and null correct-go RT against literal input; aggregate all-omitted run asserts48 omissions/rate1 and null RT quantiles. No fabricated zero/1000 distribution. Software scoring only.', 'OTGD-033-AND-TASK-005-01':'Both actual native aggregate tests execute full66-trial schedule with no inputs, assert48 omissions/rate1 and null median/IQR/p90; no speed value is fabricated. Physical acquisition not inferred.', 'OTGD-033-AND-TASK-008-03':'Actual Kotlin/Swift fixture suites assert exact100ms eligibility,100.001 over-budget faults, terminal-cutoff exclusion/overflow and committed terminal latch immutability. Literal software boundaries only, no physical latency qualification.'})
EXT=set('HW-005 HW-006 HW-008 HW-010 HW-011 ANA-002 ANA-003 ANA-004 ANA-005 ANA-009 ANA-013 MOD-001 MOD-012 ALC-002 ALC-004 VAL-001 VAL-002 VAL-003 VAL-006 VAL-008 BUS-001 BUS-002 BUS-003 DOC-002'.split())
GAPS={'OTGD-008-EVAL-008-02':('ASSERT-001','Symlink/FIFO/oversize and bounded stable read assertions exist and pass. No assertion mutates inode/size/mtime during load descriptor read; exact changed-input refusal THEN remains unproven. Add deterministic guarded-read mutation case.'),'OTGD-008-EVAL-004-02':('ASSERT-002','Empty category asserted; one-class and too-few-participant subgroup counts/null-rate/null-interval branches are not directly asserted. Whole-cohort single-class refusal does not establish sparse subgroup output.'),'OTGD-008-EVAL-005-02':('ASSERT-003','All-abstain null PPV/NPV asserted; explicit denominator/effective draw reporting and minimum-defined-bootstrap threshold−1/equality insufficient-draw interval semantics are not directly asserted.')}
GAPS.update({'OTGD-033-AND-TASK-004-01':('ASSERT-004','Literal wrong-first scoring assertions do not explicitly assert both wrong and subsequent correct touches remain in output event ledger. Add independent full retained ledger assertion.'),'OTGD-033-AND-TASK-004-03':('ASSERT-005','Literal RT999 and cutoff exclusion execute, but retained dispatch delay80 is not explicitly asserted. Add exact retained native/dispatch/delay fields and terminal immutability assertion.'),'OTGD-033-AND-TASK-004-04':('ASSERT-006','Equal-time opposing vector exercises right-then-left arrival only; reverse equal-time delivery and pinned pointer/sequence tie comparator need explicit literal assertions in both native suites/reference.')})
GAPS['OTGD-008-EVAL-003-02']=('ASSERT-007','Candidate28 future-source negatives use valid rows only; explicit invalid+future rejection is absent. New PM22-case supplement is replacement-source evidence only.')
# Known review defects are blocking evidence even where some related tests passed.
def findings(spec,req):
 f=[]
 if (spec==1 and req in ['SEC-002','SEC-003','SEC-004','SEC-006','SEC-007','OPS-005']) or (spec==20 and req in ['AND-ENV-001','AND-ENV-004']) or (spec==37 and req in ['AND-AUTH-001','AND-AUTH-002','AND-AUTH-004','AND-AUTH-006']):f+=['CODE-002 / security OAuth endpoint pinning']
 if (spec in [2,4,21,28] and req in ['AND-DASH-001','AND-HIST-003']) or (spec==1 and req in ['APP-012','PRD-020','PRD-036','PRD-041']):f+=['PROD-001 / UX-001 saved-state and workspace scope labels']
 if (spec in [5,30] and req=='AND-ONB-001') or (spec==1 and req in ['PRD-029','PRD-041']):f+=['PROD-002 onboarding conditional scope']
 if (spec in [3,9,26,34] and req in ['AND-CHECK-007','MODEL-005','AND-RES-003']) or (spec==1 and req in ['MOD-013','PRD-004','PRD-019','PRD-020','PRD-041']):f+=['PROD-003 missing uncertainty-policy presentation']
 if (spec==21 and req=='AND-DASH-007') or (spec==36 and req in ['AND-SET-006','AND-SET-007']) or (spec==1 and req=='APP-014'):f+=['UX-002 destination accessibility focus']
 if (spec==36 and req=='AND-SET-006') or (spec==1 and req=='APP-014'):f+=['UI-001 dark destructive contrast']
 if (spec==36 and req in ['AND-SET-002','AND-SET-006']) or (spec==30 and req=='AND-ONB-006') or (spec==1 and req=='APP-014'):f+=['UI-002 effective reduced motion']
 return f

def canonical_cases(s):
 if s['id']=='OTGD-001':return {}
 text=read(s['path']);out={}
 for chunk in re.split(r'^### Requirement:\s*',text,flags=re.M)[1:]:
  rid=re.match(r'([A-Z0-9-]+-\d+)\b',chunk)[1]
  for n,sc in enumerate(re.split(r'^#### Scenario:\s*',chunk,flags=re.M)[1:],1):
   lines=sc.splitlines();body='\n'.join(lines[1:]);body=re.split(r'^#{1,3} ',body,flags=re.M)[0].strip();out[s['id']+'-'+rid+'-'+str(n).zfill(2)]=lines[0]+' — '+re.sub(r'\s+',' ',body)
 return out
rows=[]
for s in inv:
 num=int(s['id'][-3:]);plan=R/s['dossier']/'test-plan.md';canon=canonical_cases(s);req=''
 for line in read(str(plan.relative_to(R))).splitlines():
  m=re.match(r'^### ([A-Z0-9-]+) — ',line)
  if m:req=m[1]
  if not line.startswith('| '+s['id']+'-'):continue
  cols=re.split(r'(?<!\\)\|',line);case=cols[1].strip();expected=canon.get(case,cols[2].strip().replace('\\|','|'))
  refs=[]
  if case in OV:refs=OV[case]
  else:
   for p,number,name in re.findall(r'`([^`]+):(\d+)` — ([^<]+)',cols[3]):refs.append((p,name.strip()))
  ids=[check(p,n) for p,n in refs];found=[checks[k] for k in ids if checks[k]['found']];ex=[e for c in found for e in c['execution']];asserts=sum(len(c['assertions']) for c in found)
  issues=findings(num,req);unproven=[];status='PARTIAL' if found else 'NOT_RUN'
  scope='Related source assertions and named observations only; full canonical GIVEN/WHEN/THEN linkage is not established by these related checks.'
  if num==1 and req in EXT:status='BLOCKED';scope='External acceptance evidence required by canonical owner/gate; software tests cannot supply it.';unproven=[expected]
  elif re.search(r'TalkBack|VoiceOver|200% system|Dynamic Type|physical handset|actual supported phones|body.connected|participant connection',expected,re.I):status='BLOCKED';scope='Actual OS/accessibility or physical prerequisite absent; controlled fixtures/builds may provide partial software support only.';unproven=[expected]
  elif not found:unproven=[expected];scope='No precise existing assertion source established in this case mapping; execute appropriate review or add meaningful acceptance assertions. This is not evidence of a code defect.'
  elif not ex:status='NOT_RUN';scope='Existing source assertions located but no admitted current-candidate named execution observation for the mapped symbols.';unproven=[expected]
  else:unproven=[expected]
  if case in PASS and not issues and found and ex and all(e['status']=='PASS' for e in ex):status='PASS';scope=PASS[case];unproven=[]
  if case in GAPS:status='PARTIAL';unproven=[GAPS[case][1]]
  if issues:status='PARTIAL' if found or ex else 'NOT_RUN';scope='Related independent review finding; this broad case still requires exact semantic body/owner review. The tag alone does not establish a software defect in this criterion. '+ '; '.join(issues);unproven=[expected]
  if case=='OTGD-019-AND-ALC-004-02':status='PARTIAL';scope='Expiry/server refusal and no-acquisition guards execute with hypothetical software authority, but no qualified instrument exists and required participant recalibration action is not demonstrated.';unproven=['Real qualified instrument/calibration expiry-to-recalibration journey and actionable recovery; absent-adapter reason must not be fabricated as calibration diagnosis.']
  rows.append({'adjudication_state':'CLAUSE_REVIEWED' if case in PASS or case in GAPS or (issues and num!=1) or status=='BLOCKED' else 'AUDIT_PENDING','remaining_category':'software_assertion_gap' if case in GAPS else 'related_review_finding_requires_clause_review' if issues and num==1 else 'remediable_software_defect' if issues else 'external_prerequisite' if status=='BLOCKED' else 'manual_or_assertion_audit_pending','remaining_then_clauses':[x.strip(' -') for x in re.split(r'\*\*(?:THEN|AND)\*\*',expected)[1:] if x.strip()] if status!='PASS' else [],'case_id':case,'spec_id':s['id'],'requirement_id':req,'canonical_path':s['path'],'canonical_sha256':source_sha(s['path']),'candidate':C,'expected_observation':expected,'status':status,'scope_judgment':scope,'source_assertion_refs':ids,'current_named_observation_count':len(ex),'assertion_line_count':asserts,'blocking_review_findings':issues,'unproven_clauses':unproven,'concrete_missing_assertion_gap':GAPS.get(case,[None,None])[0],'not_adopted_evidence':['Earlier author-focused runs and durable browser preflight remain historical/scoped until separately source-bound; previous worker drift-preflight remains FAIL.','Aggregate current job success is not proof of unasserted THEN clauses.']})
manual_path=O/'semantic-adjudications.json'
if manual_path.exists():
 for row in rows:
  update=json.loads(manual_path.read_text()).get(row['case_id'])
  if update:
   row.update(update);row['adjudication_state']='CLAUSE_REVIEWED'
   if 'source_checks' in update:
    row['source_assertion_refs']=[check(p,n) for p,n in update['source_checks']]
    row['current_named_observation_count']=sum(len(checks[k]['execution']) for k in row['source_assertion_refs'])
    row['assertion_line_count']=sum(len(checks[k].get('assertions',[])) for k in row['source_assertion_refs'])
    if row['status']=='PASS':assert row['current_named_observation_count']>0
for backend_path in [X/'verification-backend/case-adjudication.json',X/'verification-backend/second-batch/case-adjudication.json',X/'verification-backend/third-batch/case-adjudication.json',X/'verification-backend/fourth-batch/case-adjudication.json']:
 if not backend_path.exists():continue
 backend=json.loads(backend_path.read_text());assert backend['binding']['candidate']==C
 source=json.loads((backend_path.parent/'source-assertions.json').read_text());checks.update(source)
 by_id={r['case_id']:r for r in backend['rows']}
 for row in rows:
  if row['case_id'] in by_id:
   assert row['canonical_sha256']==by_id[row['case_id']]['canonical_sha256']
   row.update(by_id[row['case_id']]);row['adjudication_state']='CLAUSE_REVIEWED';row['remaining_category']=row['category'];row['remaining_then_clauses']=row['unproven_clauses']
participant_path=X/'verification-participant/final-batch.json'
if participant_path.exists():
 participant=json.loads(participant_path.read_text());assert participant['metadata']['candidate']==C
 checks.update(json.loads((participant_path.parent/'final-source-assertions.json').read_text()))
 by_id={r['case_id']:r for r in participant['rows']}
 for row in rows:
  if row['case_id'] in by_id:
   upd=by_id[row['case_id']];assert row['canonical_sha256']==upd['canonical_sha256']
   row.update(upd)
   if upd['status']=='AUDIT_PENDING':row['status']='PARTIAL';row['adjudication_state']='AUDIT_PENDING'
   else:row['adjudication_state']='CLAUSE_REVIEWED'
for native_path in [X/'verification-native/case-adjudications.json',X/'verification-native/store/case-adjudications.json']:
 if not native_path.exists():continue
 native=json.loads(native_path.read_text());assert native['binding']['candidate']==C
 checks.update(json.loads((native_path.parent/'source-assertions.json').read_text()))
 native_updates=json.loads((native_path.parent/'semantic-adjudications.json').read_text())
 for row in rows:
  if row['case_id'] in native_updates:
   upd=native_updates[row['case_id']];row.update(upd);row['adjudication_state']='CLAUSE_REVIEWED'
   row['source_assertion_refs']=[check(p,n) for p,n in upd['source_checks']]
   row['current_named_observation_count']=sum(len(checks[k].get('execution',[])) for k in row['source_assertion_refs'])
   row['assertion_line_count']=sum(len(checks[k].get('assertions',[])) for k in row['source_assertion_refs'])
   if row['status']=='PASS':assert row['current_named_observation_count']>0
fullspec_path=X/'verification-participant/fullspec/final-batch.json'
if fullspec_path.exists():
 full=json.loads(fullspec_path.read_text());assert full['metadata']['candidate']==C
 checks.update(json.loads((fullspec_path.parent/'final-source-assertions.json').read_text()))
 by_id={r['case_id']:r for r in full['rows']}
 for row in rows:
  if row['case_id'] in by_id:
   upd=by_id[row['case_id']];assert row['canonical_sha256']==upd['canonical_sha256'];row.update(upd);row['adjudication_state']='CLAUSE_REVIEWED'
# Final shared-body followups, inspected independently after specialist boundary handoff.
for row in rows:
 if row['status']=='PASS' and row.get('remaining_category')=='manual_or_assertion_audit_pending':row['remaining_category']='scoped_software_complete'
 if row['case_id']=='OTGD-041-EVAL-002-03':
  row['remaining_category']='deployment_admission_assertion_gap'
  row['unproven_clauses']=row['remaining_then_clauses']=['CLI outputs are explicitly engineering_synthetic/unvalidated with authority flags false. Reviewed deployment maintenance dispatch invokes resource bootstrap, migration and recovery admission, not a study/model fixture seed. No executed negative attempts to admit the exact generated engineering artifact as a human-approved deployed model were located; factual absence of a configured real study is not scientific approval.']
  row['scope_judgment']+=' Shared deployment source was inspected: deploy/platform.py maintenance dispatch and infra/local/bootstrap_resources.py initialize resources/authority anchors; no fixture/model loader execution proves this generated-artifact negative.'
  row['source_assertion_refs'] += [check('deploy/platform.py','main'),check('infra/local/bootstrap_resources.py','initialize')]
 if row['case_id']=='OTGD-042-HR-AUTH-007-02':
  row['remaining_category']='publication_assertion_and_source_concern'
  row['unproven_clauses']=row['remaining_then_clauses']=['Current cached replay/result GET after post-acceptance revocation is not executed by reviewed tests. Static concern in candidate28: result_get and check_view call safe_result; safe_result validates internal1.1proof/hashes but does not resolve current registry authority. verify_current_execution resolves current authority at worker commit only. This requires precedence/current-source review and a focused reproduction before a production-defect claim; no verifier test was run.']
  row['scope_judgment']+=' Shared commit test refuses model revocation and leaves stored resultnull; this proves commit, not subsequent numeric GET after earlier accepted commit. Published concern sentPM without executing reproduction or expanding round1.'
  row['source_assertion_refs'] += [check('services/api/tests/test_model_admission.py','test_model_retirement_and_consent_change_between_compute_and_commit'),check('services/api/otgd/main.py','result_get'),check('services/api/otgd/domain.py','safe_result'),check('services/api/otgd/model_engine.py','verify_current_execution')]
 if row['case_id'] in ['OTGD-041-EVAL-002-03','OTGD-042-HR-AUTH-007-02']:
  row['current_named_observation_count']=sum(len(checks[k].get('execution',[])) for k in row['source_assertion_refs']);row['assertion_line_count']=sum(len(checks[k].get('assertions',[])) for k in row['source_assertion_refs'])
# Related broad review tags cannot contradict a scoped semantic PASS; retain their history and exact unaffected scope.
for row in rows:
 if row['status']=='PASS' and row.get('blocking_review_findings'):
  row['related_review_findings']=row['blocking_review_findings']
  row['review_finding_scope_disposition']='Broad original mapping retained for traceability. Exact PASS is restricted to the proven clause: proof/parser refusal, legacy/unadmitted boundary, fictional measurement-only completion or late-history fencing. The tagged research-presentation/endpoint correction is not established by this PASS and remains open in its affected rows; no overall feature signoff.'
  row['blocking_review_findings']=[]
assert len(rows)==len({r['case_id'] for r in rows})==782
assert len({(r['spec_id'],r['requirement_id']) for r in rows})==411
write('candidate-binding.json',binding);write('evidence-index.json',{'captured_at':NOW,'binding':binding,'xml_artifacts':xmls,'named_observations':observed,'unit_raw_log':{'path':str(unitlog),'sha256':unitsha},'current_ci_snapshot':json.loads((X/'ci-candidate28-final.json').read_text()),'cancelled_worker_artifact':{'path':str(next((X/'ci-artifacts/cancelled-localstack').glob('*.json'))),'sha256':sha(next((X/'ci-artifacts/cancelled-localstack').glob('*.json'))),'state':'running/partial when CI cancelled;5stage observations but no final status/source-after/DLQ completion, NOT PASS'},'local_gate_state':'PM reports intentionally stopped after unit/ATDD/performance/components PASS at next PG collection boundary; source before/after matched. Not a complete local aggregate PASS.','preflight_browser':'docs/factory/.../reports/browser-live: actual two-viewports07:19 receipts/log, explicitly preflight; not automatically final candidate result.','worker_preflight':'Source drift failed; never adopted as PASS.'});write('source-assertions.json',checks);write('case-reconciliation.json',{'binding':binding,'status_semantics':{'PASS':'Full narrow software case checked against explicit assertions and current named execution evidence; no council/scientific/release approval.','PARTIAL':'Some source/assertion/execution support or known blocking finding; full criterion is not proven.','NOT_RUN':'No admitted current execution for exact mapped case, or manual/assertion coverage not established.','BLOCKED':'Required external/actual OS/physical prerequisite absent; no software substitution.'},'rows':rows})
with (O/'case-reconciliation.csv').open('w',newline='') as f:
 cols=['case_id','spec_id','requirement_id','status','canonical_path','canonical_sha256','candidate','expected_observation','scope_judgment','source_assertion_refs','current_named_observation_count','assertion_line_count','blocking_review_findings','unproven_clauses','concrete_missing_assertion_gap'];w=csv.DictWriter(f,fieldnames=cols);w.writeheader()
 for row in rows:w.writerow({k:json.dumps(row[k],ensure_ascii=False) if isinstance(row[k],list) else row[k] for k in cols})
# Readable one-row-per-case index, with complete source assertions/evidence stored by reference in JSON.
for spec in inv:
 sr=[r for r in rows if r['spec_id']==spec['id']];text=f'# {spec["id"]} — frozen candidate case reconciliation\n\nCandidate `{C}`. Source SHA-256 `{source_sha(spec["path"])}`. No council signoff; status definitions in report.md. Full expected clauses and assertion/evidence bindings are in case-reconciliation.json/source-assertions.json/evidence-index.json.\n\n| Stable case | Status | Actual assertion symbols | Current named observations | Unproven scope / finding |\n|---|---|---|---:|---|\n'
 for row in sr:
  clean=lambda x:re.sub(r'\s+',' ',str(x)).replace('|','\\|')
  text+='| '+row['case_id']+' | '+row['status']+' | '+clean('; '.join(row['source_assertion_refs']) or 'No exact assertion established')+' | '+str(row['current_named_observation_count'])+' | '+clean(row['scope_judgment'])+' |\n'
 (O/(spec['id']+'-cases.md')).write_text(text)
counts=dict(collections.Counter(r['status'] for r in rows));summary={'binding':binding,'cases':len(rows),'requirement_occurrences':411,'status_counts':counts,'unique_assertion_symbols':len(checks),'found_assertion_symbols':sum(x.get('found',True) for x in checks.values()),'semantic_audit_state_counts':dict(collections.Counter(r['adjudication_state'] for r in rows)),'current_named_observations':len(observed),'known_blocking_review_case_rows':sum(bool(r['blocking_review_findings']) for r in rows),'concrete_software_assertion_gaps':[{'case_id':k,'id':v[0],'gap':v[1]} for k,v in GAPS.items()],'supporting_literal_sources':{p:source_sha(p) for p in ['apps/mobile/modules/reaction-task/fixtures/golden.json','openspec/changes/production-mobile-platform/fixtures/reaction-task-golden-v1.json','apps/mobile/modules/reaction-task/fixtures/configuration.json']},'pending':'Historical case audit complete; PM round1 corrections require affected-case invalidation and new frozen-candidate exact evidence. Candidate28 local aggregate stopped deliberately and remote aggregate failed; checkpoint8 fullCI is separate historical source. No replacement aggregate or council acceptance is inferred.'};write('summary.json',summary)
print(json.dumps({k:summary[k] for k in ['cases','requirement_occurrences','status_counts','unique_assertion_symbols','found_assertion_symbols','current_named_observations','known_blocking_review_case_rows']},indent=2))
