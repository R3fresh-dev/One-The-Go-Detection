from pathlib import Path
import json,hashlib,subprocess,collections
O=Path('/workspace/scratch/otgd-20261025-0555-live/verification');R=Path('/workspace/One-The-Go-Detection');C='28e07295cb37bb9dcaaac82cc8fc846eb89006a6'
a=json.loads((O/'case-reconciliation.json').read_text());checks=json.loads((O/'source-assertions.json').read_text());rows=a['rows'];errors=[];sources={};artifacts={}
for key,c in checks.items():
 p=c['path']
 if p not in sources:
  raw=subprocess.check_output(['git','show',C+':'+p],cwd=R);sources[p]=hashlib.sha256(raw).hexdigest()
 expected=c.get('file_sha256',c.get('source_sha256'))
 if expected and sources[p]!=expected:errors.append({'kind':'source_hash','symbol':key,'expected':expected,'actual':sources[p]})
 if c.get('body_sha256') and hashlib.sha256(c['body'].encode()).hexdigest()!=c['body_sha256']:errors.append({'kind':'body_hash','symbol':key})
 for e in c.get('execution',[]):
  p=e.get('artifact',e.get('artifact_path'));d=e.get('artifact_sha256',e.get('sha256'))
  if p and d:
   if p not in artifacts:artifacts[p]=hashlib.sha256(Path(p).read_bytes()).hexdigest()
   if artifacts[p]!=d:errors.append({'kind':'artifact_hash','symbol':key,'path':p})
for r in rows:
 p=r['canonical_path']
 if p not in sources:sources[p]=hashlib.sha256(subprocess.check_output(['git','show',C+':'+p],cwd=R)).hexdigest()
 if r['canonical_sha256']!=sources[p]:errors.append({'kind':'canonical_hash','case':r['case_id']})
 for ref in r['source_assertion_refs']:
  if ref not in checks:errors.append({'kind':'missing_ref','case':r['case_id'],'ref':ref})
 if r['status']=='PASS':
  if r['unproven_clauses']:errors.append({'kind':'pass_unproved_clause','case':r['case_id']})
  if not r['source_assertion_refs'] or not all(checks[k].get('execution') for k in r['source_assertion_refs']):errors.append({'kind':'pass_without_every_named_execution','case':r['case_id']})
  if any(e.get('status')!='PASS' for k in r['source_assertion_refs'] for e in checks[k].get('execution',[])):errors.append({'kind':'pass_with_nonpassing_observation','case':r['case_id']})
  if r['adjudication_state']!='CLAUSE_REVIEWED':errors.append({'kind':'pass_unaudited','case':r['case_id']})
assert len(rows)==len(set(r['case_id'] for r in rows))==782
assert len(set((r['spec_id'],r['requirement_id']) for r in rows))==411
result={'candidate':C,'cases':782,'requirement_occurrences':411,'status_counts':dict(collections.Counter(r['status'] for r in rows)),'adjudication_counts':dict(collections.Counter(r['adjudication_state'] for r in rows)),'source_files_rehashed_from_immutable_git':len(sources),'source_records':len(checks),'raw_execution_files_rehashed':len(artifacts),'errors':errors,'valid_integrity':not errors,'completion':'Historical case audit integrity only; current replacement gates and explicit external prerequisites remain. No application or final verification acceptance.'}
(O/'integrity-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));raise SystemExit(bool(errors))
