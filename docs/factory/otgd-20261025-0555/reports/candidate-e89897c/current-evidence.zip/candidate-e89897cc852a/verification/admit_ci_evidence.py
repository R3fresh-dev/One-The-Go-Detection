from pathlib import Path
import hashlib,json,re,html,xml.etree.ElementTree as ET,collections,datetime
X=Path('/workspace/scratch/otgd-20261025-0555-live/candidate-e89897cc852a');O=X/'verification';C='e89897cc852a111b131eaf5c2caaf163ef201a48'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
binding=json.loads((X/'ci-tree-binding.json').read_text());assert binding['head']==C and binding['exact_tree']=='6b43a0a3058eb30bddb08d9476ca58929e7733f1'
items={};indices=[]
for p in sorted(X.glob('ci-artifacts-verified*.json')):
 raw=p.read_bytes();a=json.loads(raw);indices.append({'path':str(p),'sha256':sha(raw)})
 if isinstance(a,dict):a=a.get('artifacts',[])
 for item in a:items[item['id']]=item
observed=[];records=[];archives=[]
for item in items.values():
 archive=Path(item['archive']);assert sha(archive.read_bytes())==item['sha256']
 archives.append({k:item[k] for k in ['id','name','archive','sha256','bytes']})
 entrymap={Path(e['path']).name:e for e in item['entries']}
 for e in item['entries']:
  p=Path(e['path']);raw=p.read_bytes();assert sha(raw)==e['sha256']
  # Keep every supplied raw entry except nested ZIP copies; those have their own indexed digest.
  rel=p.relative_to(Path(item['archive']).parent/'extracted');target=O/'evidence-snapshots/current-ci'/str(item['id'])/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
  rec={'artifact_id':item['id'],'artifact_name':item['name'],'original_path':str(p),'snapshot_path':str(target),'sha256':e['sha256'],'bytes':len(raw)};records.append(rec)
  if p.suffix=='.xml':
   root=ET.fromstring(raw);cases=root.findall('.//testcase')
   if not cases:continue
   rec['testcase_counts']=dict(collections.Counter('FAIL' if n.find('failure') is not None or n.find('error') is not None else 'SKIP' if n.find('skipped') is not None else 'PASS' for n in cases))
   for n in cases:
    obs={'name':n.get('name'),'classname':n.get('classname',''),'status':'FAIL' if n.find('failure') is not None or n.find('error') is not None else 'SKIP' if n.find('skipped') is not None else 'PASS','artifact':str(target),'artifact_sha256':e['sha256'],'artifact_id':item['id'],'ci_run':binding['run_id'],'time':n.get('time')}
    if p.name.startswith('ios-'):
     logentry=entrymap.get(p.with_suffix('.log').name);assert logentry, p
     log=Path(logentry['path']).read_text();lines=[i for i,l in enumerate(log.splitlines(),1) if n.get('name') in l and 'passed' in l]
     assert lines,(p,n.get('name'));obs.update(native_log_sha256=logentry['sha256'],native_pass_log_lines=lines)
    observed.append(obs)
  elif p.name=='index.html' and 'expo.modules.' in str(p):
   for tr in re.findall(r'<tr>(.*?)</tr>',raw.decode(),re.S):
    cells=re.findall(r'<td[^>]*>(.*?)</td>',tr,re.S)
    if len(cells)>=7 and 'class="success"' in tr:
     name=html.unescape(re.sub('<[^>]+>','',cells[0])).strip()
     if not re.fullmatch(r'[A-Za-z_]\w*',name):continue
     assert cells[2].strip()=='1' and cells[3].strip()=='0' and cells[4].strip()=='0'
     observed.append({'name':name,'classname':p.parent.name,'status':'PASS','artifact':str(target),'artifact_sha256':e['sha256'],'artifact_id':item['id'],'ci_run':binding['run_id'],'time':cells[5]})
# Actual portable executables are bound by their compile source plus unique post-assertion stdout.
firmware_markers={
 'firmware/tests/protocol_core_test.cpp':'Protocol core: CRC, strict JSON/Unicode/duplicates, bounds, framing, replay fragments and timeout passed',
 'firmware/tests/signed_reader_acquisition_test.cpp':'Actual ADC scheduler/extractor: contact, timestamps, calibration, bounds, drops, cutoff; serialized origin transition and expiry negatives passed',
 'firmware/tests/signed_reader_grant_test.cpp':'Actual backend HTTP fixture: protected-SPKI P256 signature, 22-byte NUL domain, exact material SHA and scope/expiry/mutation negatives passed',
 'firmware/tests/sparkfun_ppg_test.cpp':'Actual pinned SDK I2C bytes, mode1/2 decode, short/error/stale read and production-core deadlines/contact/quality/cancel checks passed'}
for name in ['ci-firmware.log','ci-protected-reader.log','ci-native-android.log','ci-ios-step-results.json']:
 p=X/name
 if not p.exists():continue
 raw=p.read_bytes();target=O/'evidence-snapshots/current-ci/raw'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);records.append({'original_path':str(p),'snapshot_path':str(target),'sha256':sha(raw),'bytes':len(raw),'kind':'actual_current_job_log_or_step_receipt'})
 if name=='ci-firmware.log':
  text=raw.decode();lines=text.splitlines()
  for source,marker in firmware_markers.items():
   assert Path(source).name in text,source
   passed=[i for i,l in enumerate(lines,1) if marker in l and not l.lstrip().startswith('echo ')]
   assert passed,(source,marker)
   observed.append({'name':'main','classname':source,'status':'PASS','artifact':str(target),'artifact_sha256':sha(raw),'ci_run':binding['run_id'],'pass_log_lines':passed,'raw_observation':marker,'basis':'Actual compiler source and executed portable binary post-assertion stdout. Not physical hardware qualification.'})
write('ci-named-observations.json',observed);write('ci-artifact-inventory.json',{'candidate':C,'tree_binding':binding,'manifest_indices':indices,'archives_independently_rehashed':archives,'entries_independently_rehashed':records,'named_observations':len(observed),'native_xml_pass_names_crosschecked_with_raw_logs':sum('native_log_sha256'in e for e in observed),'scope':'Actual current named observations only. Aggregate14jobs/local7gates remain separately required; no baseline artifact adopted.'})
# Merge exact immutable snapshots, retaining source attribution and avoiding repeat duplicates.
local=json.loads((O/'named-observations.json').read_text());merged={ (e['artifact_sha256'],e['name'],e.get('classname','')):e for e in local+observed};write('named-observations.json',list(merged.values()))
print('verified archives',len(archives),'entries',len(records),'current CI named observations',len(observed),'total current named',len(merged))
