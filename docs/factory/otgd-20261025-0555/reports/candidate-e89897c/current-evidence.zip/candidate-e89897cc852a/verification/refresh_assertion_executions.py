from pathlib import Path
import json,hashlib
O=Path('/workspace/scratch/otgd-20261025-0555-live/candidate-e89897cc852a/verification')
a=json.loads((O/'source-assertions.json').read_text());obs=json.loads((O/'named-observations.json').read_text())
for key,c in a.items():
 if c.get('source_origin')=='EXTERNAL_INDEPENDENT_VERIFICATION_DRIVER':continue
 p,name=c['path'],c['name'];found=[];previous_names={e['name'] for e in c.get('execution',[])} if c.get('dynamic_test_binding') else set()
 for e in obs:
  if p.endswith('.py'):good=Path(p).stem in e['classname'].replace('/','.').split('.') and (e['name']==name or e['name'].startswith(name+'['))
  elif p.endswith(('.ts','.tsx')):good=(e['name']==name or e['name'] in previous_names) and (e['classname'] in [Path(p).name,'node_unit_unambiguous_name'] or Path(p).name in e['classname'])
  elif p.endswith('.cpp'):good=e['name']==name and e['classname']==p
  else:good=e['name']==name
  if good:found.append(e)
 c['execution']=found
 if name.startswith('STATIC_'):
  # Documentary criteria have a real immutable source inspection, never a test result.
  out=O/'document-inspections'/p;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(c['body']);raw=out.read_bytes()
  assert hashlib.sha256(raw).hexdigest()==c['file_sha256']
  c['execution']=[{'name':name,'classname':'documentary_inspection','status':'PASS','kind':'DOCUMENT_INSPECTION','artifact':str(out),'artifact_sha256':hashlib.sha256(raw).hexdigest(),'command':['git','show','e89897cc852a111b131eaf5c2caaf163ef201a48:'+p],'scope':'Actual immutable document read for documentary clause only; no software/native/store execution inferred.'}]
(O/'source-assertions.json').write_text(json.dumps(a,indent=2)+'\n')
print('sources with current observations',sum(bool(c['execution']) for c in a.values()),'of',len(a))
