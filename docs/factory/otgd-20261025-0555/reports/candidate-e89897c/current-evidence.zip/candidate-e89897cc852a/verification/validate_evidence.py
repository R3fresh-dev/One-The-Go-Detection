from pathlib import Path
import hashlib,json,subprocess,collections,datetime
R=Path('/workspace/One-The-Go-Detection');X=Path('/workspace/scratch/otgd-20261025-0555-live/candidate-e89897cc852a');O=X/'verification';C='e89897cc852a111b131eaf5c2caaf163ef201a48'
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
binding=load(X/'candidate-binding.json');d=load(O/'case-evidence.json');rows=d['rows'];a=load(O/'source-assertions.json');old=load(X.parent/'verification/case-reconciliation.json')['rows'];errors=[];files={};artifacts={};helpers=0
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==C
assert subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)==''
fingerprint=hashlib.sha256();names=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=R).split(b'\0');fc=0
for name in sorted(set(n for n in names if n)):
 p=R/name.decode()
 if p.is_file():fingerprint.update(name+b'\0'+p.read_bytes());fc+=1
assert fingerprint.hexdigest()==binding['source_fingerprint_sha256'] and fc==1299
for k,c in a.items():
 p=c['path']
 if p not in files:files[p]=Path(p).read_bytes() if c.get('source_origin')=='EXTERNAL_INDEPENDENT_VERIFICATION_DRIVER' else subprocess.check_output(['git','show',C+':'+p],cwd=R)
 if sha(files[p])!=c['file_sha256']:errors.append('source hash '+k)
 if sha(c['body'].encode())!=c['body_sha256']:errors.append('body hash '+k)
 if c['body'] not in files[p].decode():errors.append('body not in exact source '+k)
 for h in c.get('helpers',[]):
  helpers+=1;h['body_sha256']=sha(h['body'].encode())
  if h['body'] not in files[p].decode():errors.append('helper not in exact source '+k+' '+h['name'])
 for e in c.get('execution',[]):
  ep=e['artifact'];expected=e['artifact_sha256']
  if ep not in artifacts:artifacts[ep]=sha(Path(ep).read_bytes())
  if artifacts[ep]!=expected:errors.append('artifact hash '+ep)
assert {r['case_id'] for r in rows}=={r['case_id'] for r in old}
assert len(rows)==len({r['case_id'] for r in rows})==782
assert len({(r['spec_id'],r['requirement_id']) for r in rows})==411
assert len({r['spec_id'] for r in rows})==47
for r in rows:
 if not r['audit_completed'] or 'PENDING' in r['adjudication_state']:errors.append('unaudited '+r['case_id'])
 if any(k not in a for k in r['current_source_assertion_refs']):errors.append('missing ref '+r['case_id'])
 if r['status']=='PASS' and (r['unproved_then_clauses'] or r['missing_named_test_executions'] or not r['actual_named_observations']):errors.append('unbound PASS '+r['case_id'])
 if r['status']!='PASS' and not r['unproved_then_clauses']:errors.append('unexplained non-PASS '+r['case_id'])
 for e in r['actual_named_observations']:
  if e['artifact'] not in artifacts:artifacts[e['artifact']]=sha(Path(e['artifact']).read_bytes())
  if artifacts[e['artifact']]!=e['artifact_sha256']:errors.append('case artifact '+r['case_id'])
# Actual helper hashes are also durable, without changing original history.
(O/'source-assertions.json').write_text(json.dumps(a,indent=2)+'\n')
for spec in binding['canonical_specs']:
 raw=subprocess.check_output(['git','show',C+':'+spec['path']],cwd=R);assert sha(raw)==spec['sha256']
 rr=load(O/'specs'/spec['id']/'test-results.json');assert rr['canonical_sha256']==spec['sha256'] and set(rr['case_ids'])=={r['case_id'] for r in rows if r['spec_id']==spec['id']}
assert not errors,errors
result={'candidate':C,'validated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_fingerprint_sha256':fingerprint.hexdigest(),'source_fingerprint_files':fc,'canonical_specs':47,'stable_cases':782,'requirements':411,'audit_pending':0,'source_assertion_records':len(a),'distinct_source_or_driver_files':len(files),'helper_body_records_verified':helpers,'distinct_actual_artifact_files_rehashed':len(artifacts),'errors':errors,'scope':'Integrity of current source/body/helper/artifact/ID and disposition references only; not proof of unasserted clauses or final approval.'};(O/'integrity.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
