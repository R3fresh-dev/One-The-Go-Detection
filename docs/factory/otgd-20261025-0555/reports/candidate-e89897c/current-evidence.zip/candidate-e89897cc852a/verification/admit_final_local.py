from pathlib import Path
import json,hashlib,subprocess,xml.etree.ElementTree as ET,collections
R=Path('/workspace/One-The-Go-Detection');X=Path('/workspace/scratch/otgd-20261025-0555-live/candidate-e89897cc852a');O=X/'verification';C='e89897cc852a111b131eaf5c2caaf163ef201a48'
def sha(b):return hashlib.sha256(b).hexdigest()
m=json.loads((X/'local-final-artifacts.json').read_text());b=json.loads((X/'candidate-binding.json').read_text());assert m['revision']==C and m['fingerprint']==b['source_fingerprint_sha256'] and m['source_before_after_equal'] and m['clean'] and m['exit_code']==0;assert len(m['gates']['passed'])==7
obs=json.loads((O/'named-observations.json').read_text());added=[];counts={};worker=None
for e in m['artifacts']:
 p=Path(e['path']);raw=p.read_bytes();assert sha(raw)==e['sha256'],p
 if p.suffix=='.xml' and p.name!='coverage.xml':
  root=ET.fromstring(raw);cases=root.findall('.//testcase');assert cases;assert all(all(c.find(k) is None for k in ['failure','error','skipped']) for c in cases);counts[p.name]=len(cases)
  for suite in root.iter('testsuite'):
   for n in suite.findall('testcase'):
    obs.append({'name':n.get('name'),'classname':n.get('classname',''),'project':suite.get('hostname',''),'status':'PASS','artifact':str(p),'artifact_sha256':e['sha256'],'kind':'actual_current_complete_local_gate_junit'})
 if p.name.startswith('worker-interrupt-'):
  worker=json.loads(raw);assert worker['status']=='passed' and worker['fictional'] is True and worker['source_manifest_before']==worker['source_manifest_after']
  for sp,digest in worker['source_manifest_before'].items():assert sha(subprocess.check_output(['git','show',C+':'+sp],cwd=R))==digest,sp
  assert len(worker['stages'])==5 and len(worker['result_stages'])==2 and all(s['recovered']['state']=='completed' for s in worker['stages']+worker['result_stages']);assert worker['limits']['lease_seconds']==worker['limits']['visibility_seconds']==120 and worker['limits']['max_claims']==worker['limits']['max_receives']==5
  assert len(worker['budgets']['logical_attempts'])==len(worker['budgets']['receives'])==5 and worker['budgets']['logical_attempts'][-1]['state']=='failed' and worker['budgets']['dlq_message_id']
assert worker is not None and counts['postgres.xml']==1508 and counts['authenticated-live.xml']==2
obs=list({(e['artifact_sha256'],e['name'],e.get('classname',''),e.get('project','')):e for e in obs}.values());(O/'named-observations.json').write_text(json.dumps(obs,indent=2)+'\n')
(O/'final-local-admission.json').write_text(json.dumps({'candidate':C,'source_fingerprint_sha256':m['fingerprint'],'manifest':str(X/'local-final-artifacts.json'),'manifest_sha256':sha((X/'local-final-artifacts.json').read_bytes()),'raw_files_rehashed':len(m['artifacts']),'all_seven_gates_pass':True,'exact_named_xml_counts':counts,'unit_subtest_count_caveat':'unit.xml has1538 actual testcase elements and1746 aggregate tests including208 successful subtests; no invented208 separate named elements.','worker_source_files_rehashed_against_candidate':len(worker['source_manifest_before']),'worker_export_recoveries':5,'worker_result_recoveries':2,'worker_limits':worker['limits'],'worker_budget_claims_receives':5,'worker_scope':worker['scope'],'actual_performance':json.loads((X/'current-local/performance.json').read_text()),'scope':'Actual local software, PostgreSQL, versioned S3/SQS, process termination/recovery and browser checks. No deployed AWS, installed OS, physical sensors, participant or scientific approval.'},indent=2)+'\n')
print('Final local admitted: all7 gates,19 raw files,92 worker source hashes; current local artifact links retained without duplication')
