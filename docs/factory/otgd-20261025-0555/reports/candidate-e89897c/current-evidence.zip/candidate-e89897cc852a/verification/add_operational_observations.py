from pathlib import Path
import json,re,hashlib
X=Path('/workspace/scratch/otgd-20261025-0555-live/candidate-e89897cc852a');O=X/'verification';p=O/'evidence-snapshots/repo/reports/unit-coverage.log';raw=p.read_bytes();lines=raw.decode().splitlines();a=json.loads((O/'named-observations.json').read_text());digest=hashlib.sha256(raw).hexdigest()
for i,line in enumerate(lines):
 m=re.match(r'(test_\w+) \(([^)]+)\) \.\.\. ',line)
 if not m:continue
 end=next((j for j in range(i+1,min(i+30,len(lines))) if lines[j]=='ok'),None)
 nexttest=next((j for j in range(i+1,min(i+30,len(lines))) if re.match(r'test_\w+ \(',lines[j])),None)
 if not line.endswith('... ok') and end is not None and (nexttest is None or end<nexttest):
  a.append({'name':m[1],'classname':m[2],'status':'PASS','artifact':str(p),'artifact_sha256':digest,'line':i+1,'success_line':end+1,'raw':line+'\n...\n'+lines[end],'kind':'multiline_unittest_actual_result'})
unique={(e['artifact_sha256'],e['name'],e.get('classname','')):e for e in a};(O/'named-observations.json').write_text(json.dumps(list(unique.values()),indent=2)+'\n')
# The CI workflow deliberately redirects the individual Node report. Preserve the actual execution basis; never call it raw named XML.
p=X/'ci-contracts-and-synthesis.log';raw=p.read_bytes();text=raw.decode();command='node --import tsx --test --test-reporter=junit test/*.test.ts > ../reports/infra-node.xml';validator='python scripts/ci_gate.py verify-junit reports/infra-node.xml';assert command in text and validator in text
out=O/'evidence-snapshots/current-ci/raw'/p.name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
basis={'candidate':'e89897cc852a111b131eaf5c2caaf163ef201a48','source':'infra/test/platform.test.ts','assertion_name':'prod: synthesized network, identity, storage and queue boundaries','kind':'SOURCE_SCOPED_SUITE_EXECUTION','status':'PASS','raw_named':False,'artifact':str(out),'artifact_sha256':hashlib.sha256(raw).hexdigest(),'command':command,'fail_closed_report_validation':validator,'command_lines':[i for i,l in enumerate(text.splitlines(),1) if command in l],'validator_lines':[i for i,l in enumerate(text.splitlines(),1) if validator in l],'rationale':'Successful exact source-file suite plus inspected unconditional qa/prod registration and fail-closed JUnit validation establishes execution of its assertions. Individual infra-node.xml was redirected and not uploaded, so no raw per-method XML/name is claimed. This is explicit source/suite composition, not an aggregate-only inference.','limitation':'No retained individual infra-node.xml; no real AWS deployment/qualification.'}
(O/'infra-suite-execution-basis.json').write_text(json.dumps(basis,indent=2)+'\n')
print('multiline unittest evidence added; explicit infra suite execution/retention limitation preserved')
