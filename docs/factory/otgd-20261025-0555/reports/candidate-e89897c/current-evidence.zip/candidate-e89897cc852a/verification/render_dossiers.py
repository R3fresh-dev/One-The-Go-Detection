from pathlib import Path
import json,collections,hashlib,datetime
X=Path('/workspace/scratch/otgd-20261025-0555-live/candidate-e89897cc852a');O=X/'verification';d=json.loads((O/'case-evidence.json').read_text());checks=json.loads((O/'source-assertions.json').read_text());binding=d['binding'];C=binding['revision'];rows=d['rows'];specs=binding['canonical_specs']
def sha(b):return hashlib.sha256(b).hexdigest()
def md(t):return str(t).replace('|','\\|').replace('\n',' ')
commands={
'unit':'python scripts/ci_gate.py unit-coverage',
'postgres':'python scripts/ci_gate.py live-dependencies',
'components':'python scripts/ci_gate.py components',
'atdd':'python scripts/ci_gate.py atdd',
'live':'python scripts/ci_gate.py localstack-api',
'infra':'node --import tsx --test --test-reporter=junit test/*.test.ts (cwd: infra)',
'infra-python':'uv run --project services/api python scripts/ci_gate.py infra-unit',
'kotlin':'./gradlew --no-daemon --max-workers=2 --init-script ../modules/scripts/local-preview.init.gradle -PreactNativeDevServerPort=8082 -PreactNativeArchitectures=arm64-v8a,x86_64 :otgd-reaction-task:testDebugUnitTest :otgd-eye-capture:testDebugUnitTest :app:assembleDebug :app:assembleRelease (cwd: apps/mobile/android)',
'swift-task':'swift test --package-path apps/mobile/modules/reaction-task --parallel --num-workers 1 --verbose --disable-swift-testing --xunit-output "$PWD/reports/ios-native.xml"',
'swift-eye':'swift test --package-path apps/mobile/modules/eye-capture --parallel --num-workers 1 --verbose --disable-swift-testing --xunit-output "$PWD/reports/ios-optical.xml"',
'firmware':'Exact compiler, executable and arduino-cli commands: immutable .github/workflows/native-build.yml; actual ci-firmware.log and ci-protected-reader.log retained.',
}
index=[];reqs=[]
for spec in specs:
 sid=spec['id'];rs=[r for r in rows if r['spec_id']==sid];out=O/'specs'/sid;out.mkdir(parents=True,exist_ok=True);count=dict(collections.Counter(r['status'] for r in rs));refs=list(dict.fromkeys(k for r in rs for k in r['current_source_assertion_refs']));paths=[checks[k]['path'] for k in refs];cmd=[]
 if any(p.startswith('services/api/') or p.startswith('apps/mobile/tests/') for p in paths):cmd.append(commands['unit'])
 if any(p.startswith('services/api/') for p in paths):cmd.append(commands['postgres'])
 if any('/e2e/' in p for p in paths):cmd += [commands['components'],commands['atdd']]
 if any('authenticated-live' in p for p in paths):cmd.append(commands['live'])
 if any(p.startswith('infra/test/') for p in paths):cmd += [commands['infra-python'],commands['infra']]
 if any(p.endswith('.kt') for p in paths):cmd.append(commands['kotlin'])
 if any('reaction-task' in p and p.endswith('.swift') for p in paths):cmd.append(commands['swift-task'])
 if any('eye-capture' in p and p.endswith('.swift') for p in paths):cmd.append(commands['swift-eye'])
 if any(p.startswith('firmware/') for p in paths):cmd.append(commands['firmware'])
 cmd=list(dict.fromkeys(cmd));requirements=sorted({r['requirement_id'] for r in rs});target=spec['dossier'];summary={'spec_id':sid,'canonical_path':spec['path'],'canonical_sha256':spec['sha256'],'candidate':C,'case_ids':[r['case_id'] for r in rs],'requirements':requirements,'statuses':count,'audit_pending':0,'proposed_dossier_status':'PARTIAL_SPEC_NOT_COMPLETE' if any(r['status']!='PASS' for r in rs) else 'SCOPED_CASES_PASS_PENDING_INDEPENDENT_ACCEPTANCE','proposed_target':target,'import_authority':'PM only; this verifier does not edit repository or sign council decisions.','exact_commands':cmd,'current_source_assertion_refs':refs,'gates':'Current CI all14 PASS; independent local all7 gates passed.','restrictions':'No merge/deployment/participant use. Measurement defaults, fictional source, research eligibility, independent scientific approvals and future separately calibrated fuel-cell breath alcohol mg/L scope preserved.'}
 (out/'test-results.json').write_text(json.dumps(summary,indent=2)+'\n');index.append(summary)
 plan=[f'# {sid} current verification plan proposal','',f'Candidate `{C}`; canonical `{spec["path"]}`; SHA256 `{spec["sha256"]}`.', '',f'Proposed repository destination: `{target}/test-plan.md`. External review artifact only; PM controls import.', '',f'All {len(rs)} stable cases / {len(requirements)} requirements are preserved. The exact GIVEN/WHEN/THEN wording and negative/boundary/recovery clauses are in `test-results.md` and the central `case-evidence.json`; no renamed IDs or weakened criteria.', '', 'Current execution commands (already executed by PM/current CI where their raw observations are bound):','']+[f'- `{x}`' for x in cmd]+['','Shared full local command: `python scripts/run_all_gates.py`. Its independent local final receipt confirms all7 gates passed. No verifier tests or service mutations were run. Current CI exact-tree run 40185247204 passed all14 mandatory jobs. Exact workflow/source bindings and named artifacts are retained in `../../final-ci-admission.json` and `../../source-assertions.json`.','', 'Each remaining clause requires the minimal evidence/action recorded beside that case. Review meaningful existing shared assertions/helpers/control flow before requesting any extra execution. After correction2/2, unresolved evidence does not authorize a third source correction or a broader test project. Native/hardware/study/deployment prerequisites remain separately typed.','', '| Stable case | Planned assertion | Current disposition |','|---|---|---|']
 plan += [f'| {r["case_id"]} | {md(r["expected_observation"])} | {r["status"]} |' for r in rs]
 (out/'test-plan.md').write_text('\n'.join(plan)+'\n')
 result=[f'# {sid} current test-result proposal','',f'Candidate `{C}`; tree `{binding["tree"]}`; source fingerprint `{binding["source_fingerprint_sha256"]}`.', '',f'Canonical `{spec["path"]}`; SHA256 `{spec["sha256"]}`.', '',f'{len(rs)} cases, {len(requirements)} requirements: '+', '.join(f'{k} {v}' for k,v in sorted(count.items()))+'. Zero unaudited rows.', '', '**This is scoped case evidence, not a completed-spec/council/application/release approval.** Current CI14 jobs passed. Independent local all7 gates passed. Physical timing, predictive validity, sensing qualification and real participant authorization are not established. Fictional native fixtures remain `modelEligible=false`.', '', 'Actual current commands and evidence are indexed in `test-plan.md`, `../../source-assertions.json`, `../../named-observations.json` and `../../ci-artifact-inventory.json`. Historical candidate28/cf74fcf and author RED/GREEN remain development/history evidence; their raw outcomes are not promoted.', '']
 for r in rs:
  result += [f'## {r["case_id"]} — {r["status"]}','',r['expected_observation'],'', 'Current proof: '+' '.join(r['current_assertions_proven']),'']
  if r['current_source_assertion_refs']:
   result += ['Current source assertions (full body/helper hashes and exact execution references are in the central source index):','']+[f'- `{k}` — file SHA `{checks[k]["file_sha256"]}`, line {checks[k]["line"]}; '+str(len(checks[k]['execution']))+' current observation(s).' for k in r['current_source_assertion_refs']]
  ev={(e['artifact_sha256'],e['artifact']) for e in r['actual_named_observations']};result += ['','Actual current raw artifacts:','']+[f'- `{p}` — SHA256 `{h}`.' for h,p in sorted(ev)] if ev else ['','No current named execution is adopted for this exact scenario.']
  if r['unproved_then_clauses']:
   result += ['','Exact unproved clause(s):','']+[f'- {x}' for x in r['unproved_then_clauses']]+['','Prerequisite/evidence type: '+', '.join(r['remaining_prerequisite_types'])+'.','', 'Minimal next action: review the referenced current shared assertion/helper/control-flow proof for the literal clause above; supply a targeted observation or the identified external prerequisite if it is available. Preserve PARTIAL/NOT_RUN/BLOCKED if it is unavailable. This is not an implementation-defect finding or permission for a new correction round.']
  else:result += ['','All scoped criterion clauses are supported. Fixture limitations and external scientific/OS release gates are not converted into approval.']
  if r['evidence_limits']:result += ['','Scope limits: '+' '.join(r['evidence_limits'])]
  result += ['','Baseline history: '+r['baseline_history']['candidate']+' / '+r['baseline_history']['status']+'; record SHA '+r['baseline_history']['record_sha256']+'. Actual current source and raw evidence supply this disposition.','']
 (out/'test-results.md').write_text('\n'.join(result)+'\n')
 for rid in requirements:
  cr=[r for r in rs if r['requirement_id']==rid];reqs.append({'spec_id':sid,'requirement_id':rid,'case_ids':[r['case_id'] for r in cr],'statuses':dict(collections.Counter(r['status'] for r in cr)),'all_scoped_cases_pass':all(r['status']=='PASS' for r in cr)})
assert len(index)==47 and len(reqs)==411
(O/'dossier-proposals.json').write_text(json.dumps({'candidate':C,'specs':index},indent=2)+'\n');(O/'requirement-evidence.json').write_text(json.dumps({'candidate':C,'requirements':reqs},indent=2)+'\n')
# Classify residuals as evidence/disposition only. The pure/mixed distinction is literal, not a new defect count.
external={'native_os_execution','physical_hardware_execution','study_scientific_approval','deployment_cloud_or_owner_prerequisite','independent_owner_review','provider_credentials','deployment_cloud_prerequisite'}
soft=[r for r in rows if r['unproved_then_clauses'] and any(t.startswith('software') for t in r['remaining_prerequisite_types'])];pure=[r for r in soft if not external.intersection(r['remaining_prerequisite_types'])];mixed=[r for r in soft if external.intersection(r['remaining_prerequisite_types'])]
for name,rr in [('software-evidence-residuals',pure),('mixed-software-external-residuals',mixed),('external-prerequisites',[r for r in rows if r['unproved_then_clauses'] and external.intersection(r['remaining_prerequisite_types'])])]:
 (O/(name+'.json')).write_text(json.dumps({'candidate':C,'not_implementation_defects_or_new_test_orders':True,'case_count':len(rr),'rows':[{'case_id':r['case_id'],'status':r['status'],'exact_unproved_clauses':r['unproved_then_clauses'],'types':r['remaining_prerequisite_types'],'minimal_next_evidence_or_action':r['minimal_next_evidence_or_action']} for r in rr]},indent=2)+'\n')
print('47 dossier proposals, 411 requirement rollups; software-only evidence residual rows',len(pure),'mixed',len(mixed))
