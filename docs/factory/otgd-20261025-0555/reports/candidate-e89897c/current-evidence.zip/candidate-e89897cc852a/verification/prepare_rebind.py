from pathlib import Path
import ast,collections,datetime,hashlib,json,re,subprocess,xml.etree.ElementTree as ET
R=Path('/workspace/One-The-Go-Detection'); X=Path('/workspace/scratch/otgd-20261025-0555-live/candidate-e89897cc852a');O=X/'verification';OLD=X.parent/'verification';C='e89897cc852a111b131eaf5c2caaf163ef201a48';B='28e07295cb37bb9dcaaac82cc8fc846eb89006a6';NOW=datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
def sh(b):return hashlib.sha256(b).hexdigest()
def write(p,v):p=O/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
cache={}
def read(p):
 if p not in cache:cache[p]=git('show',C+':'+p).decode()
 return cache[p]
binding=json.loads((X/'candidate-binding.json').read_text());assert git('rev-parse','HEAD').decode().strip()==C;assert git('rev-parse',C+'^{tree}').decode().strip()==binding['tree']
source_names=sorted(set(x for x in git('ls-files','-z','--cached','--others','--exclude-standard').split(b'\0') if x));fingerprint=hashlib.sha256();file_hashes={}
for name in source_names:
 p=R/name.decode()
 if p.is_file():
  raw=p.read_bytes();fingerprint.update(name+b'\0'+raw);file_hashes[name.decode()]=sh(raw)
assert fingerprint.hexdigest()==binding['source_fingerprint_sha256'],fingerprint.hexdigest()
canonical={s['id']:s for s in binding['canonical_specs']};assert len(canonical)==47
for s in canonical.values():assert sh(read(s['path']).encode())==s['sha256']
changed=git('diff','--name-only',B,C).decode().splitlines();changed_set=set(changed)
changed_canonical=[{'spec_id':s['id'],'path':s['path'],'before_sha256':sh(git('show',B+':'+s['path'])),'current_sha256':s['sha256']} for s in canonical.values() if s['path'] in changed_set]
write('source-binding.json',{'captured_at':NOW,'candidate':C,'tree':binding['tree'],'source_fingerprint_sha256':fingerprint.hexdigest(),'fingerprint_file_count':len(file_hashes),'canonical_hashes_verified':47,'canonical_changes':changed_canonical,'current_file_sha256':file_hashes,'changed_paths_since_baseline':changed,'ci_tree_binding':json.loads((X/'ci-tree-binding.json').read_text()) if (X/'ci-tree-binding.json').exists() else None,'scope':'Independent read-only binding. Not passing gate/approval evidence.'})
# Snapshot only closed current-stage files; stale ignored reports are excluded.
stage=json.loads((X/'unit-stage-artifacts.json').read_text()) if (X/'unit-stage-artifacts.json').exists() else {'artifacts':[]};gate=json.loads((X/'gate-process.json').read_text());started=datetime.datetime.fromisoformat(gate['started_at']).timestamp();artifacts=[];observations=[]
def snapshot(p,kind,declared_sha=None):
 raw=p.read_bytes();d=sh(raw)
 if declared_sha:assert d==declared_sha,(p,d,declared_sha)
 rel=('repo/'+str(p.relative_to(R))) if p.is_relative_to(R) else ('candidate/'+str(p.relative_to(X)));target=O/'evidence-snapshots'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 rec={'original_path':str(p),'snapshot_path':str(target),'sha256':d,'bytes':len(raw),'kind':kind,'captured_at':NOW};artifacts.append(rec);return raw,rec
for n in stage['artifacts']:snapshot(R/n['path'],'current_closed_unit_stage',n['sha256'])
for pstr in ['reports/unit-coverage.log','reports/unit-coverage.json','reports/coverage.xml','apps/mobile/reports/mobile-unit-coverage.json']:
 p=R/pstr
 if p.exists() and p.stat().st_mtime>=started and not any(a['original_path']==str(p) for a in artifacts):snapshot(p,'current_closed_unit_stage')
xml_paths=['reports/unit.xml','reports/atdd.xml','reports/hosted-preview.xml','reports/components.xml','reports/secure-sdk.xml']
for pstr in xml_paths:
 p=R/pstr
 if not p.exists() or p.stat().st_mtime<started:continue
 prior=next((x for x in artifacts if x['original_path']==str(p)),None)
 raw,rec=(p.read_bytes(),prior) if prior else snapshot(p,'current_named_junit')
 root=ET.fromstring(raw);cases=root.findall('.//testcase');counts=collections.Counter('FAIL' if n.find('failure') is not None or n.find('error') is not None else 'SKIP' if n.find('skipped') is not None else 'PASS' for n in cases);rec['case_counts']=dict(counts)
 for n in cases:observations.append({'name':n.get('name'),'classname':n.get('classname',''),'status':'FAIL' if n.find('failure') is not None or n.find('error') is not None else 'SKIP' if n.find('skipped') is not None else 'PASS','artifact_sha256':rec['sha256'],'artifact':rec['snapshot_path'],'time':n.get('time')})
unit_path=O/'evidence-snapshots/repo/reports/unit-coverage.log';unitraw=unit_path.read_text() if unit_path.exists() else '';unitrec=next((x for x in artifacts if x['original_path']==str(R/'reports/unit-coverage.log')),None)
for number,line in enumerate(unitraw.splitlines(),1):
 m=re.search(r'✔ (.+?) \([0-9.]+m?s\)',line)
 if m:observations.append({'name':m[1],'classname':'node_unit_unambiguous_name','status':'PASS','artifact':unitrec['snapshot_path'],'artifact_sha256':unitrec['sha256'],'line':number,'raw':line})
 m=re.search(r'\b(test_[A-Za-z0-9_]+) \(([^)]+)\).*\.\.\. ok$',line)
 if m:observations.append({'name':m[1],'classname':m[2],'status':'PASS','artifact':unitrec['snapshot_path'],'artifact_sha256':unitrec['sha256'],'line':number,'raw':line})
for pstr in ['reports/atdd.log','reports/components.log','reports/performance.json','reports/performance.log']:
 p=R/pstr
 if p.exists() and p.stat().st_mtime>=started:snapshot(p,'current_closed_stage_raw')
if (X/'ci-components.log').exists():snapshot(X/'ci-components.log','current_ci_component_raw_log')
for p in sorted((R/'docs/factory/otgd-20261025-0555/reports').glob('correction-*.md')):
 snapshot(p,'committed_author_report_development_evidence_only')
stop=json.loads((X/'intentional-stop.json').read_text()) if (X/'intentional-stop.json').exists() else None
if stop:
 assert stop['revision']==C and stop['source_unchanged'] and stop['source_fingerprint_after']==binding['source_fingerprint_sha256']
 snapshot(X/'intentional-stop.json','confirmed_intentional_partial_stop')
 archive=Path(stop['archive']);assert sh(archive.read_bytes())==stop['archive_sha256']
 gate={'launch':gate,'stop':stop,'passed_stages':['unit-coverage','atdd','performance','components'],'postgres':'INTERRUPTED_NOT_PASS;96partialtests and teardown error; no PostgreSQL complete-gate admission','archive_sha256_verified':True}
write('evidence-inventory.json',{'candidate':C,'captured_at':NOW,'artifacts':artifacts,'named_observation_count':len(observations),'current_local_gate_state':gate,'full_local_pass':False,'full_current_ci_pass':False,'limitations':['Gate is/was running, no final before/after receipt admitted. Closed stage raw outputs are scoped observations only.','Checkpoint28/8/9 and authorREDGREEN are historical/development evidence, never a new whole-case PASS.','Current CI tree binding is verified; only locally supplied current raw artifacts are inventoried. Missing native/firmware/PG/live artifacts remain pending.','Native OS/hardware/science/study/cloud/store prerequisites are distinct.']});write('named-observations.json',observations)
# Current bodies and named executions for original symbols. New supplements merge separately.
old=json.loads((OLD/'case-reconciliation.json').read_text());oldchecks=json.loads((OLD/'source-assertions.json').read_text());currentchecks={};module_cache={}
def module(p):
 if p not in module_cache:
  t=read(p);defs={}
  if p.endswith('.py'):
   tree=ast.parse(t);lines=t.splitlines()
   for n in ast.walk(tree):
    if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):defs[n.name]={'line':n.lineno,'body':'\n'.join(lines[n.lineno-1:n.end_lineno]),'node':n}
  elif p.endswith(('.ts','.tsx')):
   ms=list(re.finditer(r'\btest(?:\.\w+)?\s*\(\s*([\'\"`])(.+?)\1',t))
   for i,m in enumerate(ms):defs[m[2]]={'line':t[:m.start()].count('\n')+1,'body':t[m.start():ms[i+1].start() if i+1<len(ms) else len(t)]}
  else:
   ms=list(re.finditer(r'\b(?:func|fun|void|int)\s+([A-Za-z_]\w*)\s*\(',t))
   for i,m in enumerate(ms):defs[m[1]]={'line':t[:m.start()].count('\n')+1,'body':t[m.start():ms[i+1].start() if i+1<len(ms) else len(t)]}
  module_cache[p]=(t,defs)
 return module_cache[p]
def check(p,name):
 key=p+'::'+name
 if key in currentchecks:return key
 try:t,defs=module(p)
 except subprocess.CalledProcessError:currentchecks[key]={'path':p,'name':name,'found':False,'execution':[]};return key
 d=defs.get(name)
 if not d and name.startswith(('qa:','prod:')):
  d=next((v for k,v in defs.items() if k.replace('${env}',name.split(':')[0])==name),None)
 if not d and name.startswith('STATIC_'):d={'line':1,'body':t}
 if not d:currentchecks[key]={'path':p,'name':name,'found':False,'file_sha256':sh(t.encode()),'execution':[]};return key
 helpers=[]
 if p.endswith('.py') and 'node' in d:
  names={n.func.id for n in ast.walk(d['node']) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)}
  for n in sorted(names):
   if n in defs and not n.startswith('test_'):helpers.append({k:defs[n][k] for k in ['line','body']}|{'name':n})
 executions=[]
 for e in observations:
  if p.endswith('.py'):good=Path(p).stem in e['classname'].replace('/','.').split('.') and (e['name']==name or e['name'].startswith(name+'['))
  elif p.endswith(('.ts','.tsx')):good=e['name']==name and (e['classname'] in [Path(p).name,'node_unit_unambiguous_name'] or Path(p).name in e['classname'])
  else:good=e['name']==name
  if good:executions.append(e)
 currentchecks[key]={'path':p,'name':name,'found':True,'candidate':C,'file_sha256':sh(t.encode()),'line':d['line'],'body':d['body'],'body_sha256':sh(d['body'].encode()),'helpers':helpers,'execution':executions,'assertions':[{'line':i,'text':l.strip()} for i,l in enumerate(d['body'].splitlines(),d['line']) if re.search(r'\bassert\b|\bexpect\s*[.(]|assert\w*\(|XCTAssert|pytest.raises|\brequire\(',l)],'semantic_review':'Source extraction/current named observation only; fullcase semantic rebind pending.'};return key
def canonical_cases(spec):
 if spec['id']=='OTGD-001':return {}
 out={}
 for chunk in re.split(r'^### Requirement:\s*',read(spec['path']),flags=re.M)[1:]:
  rid=re.match(r'([A-Z0-9-]+-\d+)\b',chunk)[1]
  for i,sc in enumerate(re.split(r'^#### Scenario:\s*',chunk,flags=re.M)[1:],1):
   lines=sc.splitlines();body=re.split(r'^#{1,3} ', '\n'.join(lines[1:]),flags=re.M)[0].strip();out[spec['id']+'-'+rid+'-'+str(i).zfill(2)]=lines[0]+' — '+re.sub(r'\s+',' ',body)
 return out
current_expected={s['id']:canonical_cases(s) for s in canonical.values()}
rows=[]
for oldrow in old['rows']:
 r={k:oldrow[k] for k in ['case_id','spec_id','requirement_id','expected_observation']};s=canonical[r['spec_id']];r.update(candidate=C,canonical_path=s['path'],canonical_sha256=s['sha256'],baseline_candidate=B,baseline_status=oldrow['status'],baseline_record_sha256=sh(json.dumps(oldrow,sort_keys=True).encode()),baseline_remaining_clause=oldrow['unproven_clauses'],baseline_remaining_category=oldrow.get('remaining_category'))
 refs=[]
 for ref in oldrow['source_assertion_refs']:
  c=oldchecks[ref];refs.append(check(c['path'],c['name']))
 r['expected_observation']=current_expected[r['spec_id']].get(r['case_id'],r['expected_observation']);r['current_source_assertion_refs']=refs;r['current_named_observation_count']=sum(len(currentchecks[k].get('execution',[])) for k in refs)
 direct=[currentchecks[k]['path'] for k in refs if currentchecks[k]['path'] in changed_set];r['changed_primary_assertion_files']=sorted(set(direct));r['changed_canonical']=s['path'] in changed_set
 scopes=set()
 for k in refs:
  p=currentchecks[k]['path']
  if p.startswith('apps/mobile/'):scopes.add('mobile')
  if p.startswith('services/api/'):scopes.add('api')
  if p.startswith(('infra/','deploy/','.github/')):scopes.add('infra_deploy')
 r['changed_shared_source_inputs']=[p for p in changed if ('mobile'in scopes and p.startswith(('apps/mobile/src/','apps/mobile/app.config','apps/mobile/oauth-build'))) or ('api'in scopes and p.startswith('services/api/otgd/')) or ('infra_deploy'in scopes and p.startswith(('deploy/','infra/lib/','.github/workflows/')))]
 r['source_rebind_state']='CANONICAL_CHANGED' if r['changed_canonical'] else 'PRIMARY_OR_SHARED_SOURCE_CHANGED' if direct or r['changed_shared_source_inputs'] else 'REVALIDATE_EXACT_CURRENT_EVIDENCE'
 external=oldrow['status']=='BLOCKED';r['provisional_current_status']='BLOCKED' if external else 'PARTIAL' if r['current_named_observation_count'] else 'NOT_RUN';r['current_acceptance']='NOT_ADMITTED_PENDING_REPLACEMENT_SEMANTIC_AND_COMPLETE_GATE_EVIDENCE';r['external_prerequisites']=oldrow['unproven_clauses'] if external else []
 r['remaining_current_work']='Reconcile explicit meaningful current assertions/helpers and complete gate/source binding; baselinePASS is never transferred. Preserve scope-specific native/physical/science/study/cloud/store/owner prerequisites.';rows.append(r)
assert len(rows)==len({r['case_id'] for r in rows})==782;assert len({(r['spec_id'],r['requirement_id']) for r in rows})==411
write('case-rebind-preparation.json',{'candidate':C,'baseline_artifact':str(OLD/'case-reconciliation.json'),'baseline_artifact_sha256':sh((OLD/'case-reconciliation.json').read_bytes()),'scope':'Prepared current782case rebind, not final per-case acceptance. Baseline preserved. Current named passes alone do not upgrade a fullcriterion.','rows':rows});write('source-assertions.json',currentchecks)
write('summary.json',{'candidate':C,'cases':782,'requirements':411,'canonical_count':47,'canonical_changes':changed_canonical,'source_fingerprint_verified':True,'source_files':len(file_hashes),'current_body_records':len(currentchecks),'current_body_records_found':sum(c['found'] for c in currentchecks.values()),'named_observations':len(observations),'provisional_current_status':dict(collections.Counter(r['provisional_current_status'] for r in rows)),'source_rebind_state':dict(collections.Counter(r['source_rebind_state'] for r in rows)),'current_fullcase_passes':0,'full_local_pass':False,'full_ci_pass':False,'correction_round':2,'recovery_attempts':0})
print(json.dumps(json.loads((O/'summary.json').read_text()),indent=2))
