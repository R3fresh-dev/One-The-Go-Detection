from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET
X=Path('/workspace/scratch/otgd-20261025-0555-live/candidate-e89897cc852a');O=X/'verification';p=X/'infra-node.xml';raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()=='a5b74683ea4cfaacaf3b37d820722d94f82afbad0394396e464130a20bc7b5b5';out=O/'evidence-snapshots/current-local/infra-node.xml';out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
receipt=json.loads((X/'infra-node-execution.json').read_text());(out.parent/'infra-node-execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
a=json.loads((O/'named-observations.json').read_text());cases=ET.fromstring(raw).findall('.//testcase');assert len(cases)==6
for n in cases:
 assert all(n.find(x) is None for x in ['failure','error','skipped'])
 a.append({'name':n.get('name'),'classname':'platform.test.ts' if n.get('name','').startswith(('qa:','prod:')) else n.get('classname',''),'status':'PASS','artifact':str(out),'artifact_sha256':hashlib.sha256(raw).hexdigest(),'kind':'actual_current_unfiltered_local_infra_junit','command':'node --import tsx --test --test-reporter=junit test/*.test.ts','execution_receipt':str(out.parent/'infra-node-execution.json')})
a=list({(x['artifact_sha256'],x['name'],x.get('classname','')):x for x in a}.values());(O/'named-observations.json').write_text(json.dumps(a,indent=2)+'\n');print('current infra actual named methods',len(cases))
