// External isolated verification only. Current real controller/storage/ApiClient/sync execute;
// approvedAccount supplies explicitly fictional service/native boundaries. No OS/hardware claim.
test("supplemental offline active reader capture withdrawal retains exact privacy intent and later receipt without restoring uploads", async () => {
  const h = await approvedAccount(), entered = deferred<void>(), stopped = deferred<any>();
  const previousCapture = h.app.device.captureAuthorized;
  const trace: any[] = [];
  try {
    // A real frozen, integrity-verified local check provides an upload intent to fence.
    await h.app.beginStudyCheck(h.study.study_id, h.config.protocol_id, true);
    await h.app.captureReader("ppg", false, currentInstruction(h.app, "cardiac"));
    await h.app.saveCheck();
    const savedId = h.app.check!.id;
    await h.app.commit((state) => queueCheck(state, savedId, randomUUID, new Date().toISOString()));
    await h.app.beginStudyCheck(h.study.study_id, h.config.protocol_id, true);
    let active = false;
    (h.app.device as any).captureAuthorized = async () => {
      active = true; trace.push({event:"fictional-reader-active"}); entered.resolve();
      return await stopped.promise;
    };
    (h.app.device as any).cancelCapture = async (reason: string) => {
      trace.push({event:"device-cancel",reason,active});
      active = false; stopped.reject(new DeviceError("CAPTURE_STOPPED", "Fictional native boundary canceled capture"));
    };
    const capture = h.app.captureReader("ppg", false, currentInstruction(h.app, "cardiac"));
    await entered.promise;
    assert.equal(active,true);
    assert.equal(h.app.check!.attempts[0]!.status,"started");
    const activeId = h.app.check!.id;
    const transport = globalThis.fetch;
    const withdrawalCalls: any[] = [];
    globalThis.fetch = async (input, init) => {
      const path = new URL(String(input)).pathname;
      trace.push({event:"offline-request",path});
      if(path.endsWith("/withdrawals")) withdrawalCalls.push({path,body:JSON.parse(String(init?.body)),key:new Headers(init?.headers).get("Idempotency-Key")});
      throw new TypeError("DECLARED FICTIONAL offline transport");
    };
    await h.app.withdraw(h.study.study_id);
    await capture;
    assert.equal(active,false);
    assert.ok(trace.some(e=>e.event==="device-cancel" && e.reason==="WITHDRAWAL" && e.active));
    assert.equal(h.app.check!.id,activeId);
    assert.equal(h.app.check!.attempts[0]!.status,"invalid");
    assert.equal(h.app.check!.snapshot.cardiac.heart_rate_bpm,null);
    const pending = clone(h.app.getSnapshot().state!.queue.find(q=>q.kind==="withdrawal")!);
    const membership = h.app.getSnapshot().state!.studies.find(s=>s.study_id===h.study.study_id)!;
    assert.equal(membership.local_withdrawal_pending,true);
    assert.equal((membership.consent as any).state,"active");
    assert.notEqual(pending.state,"synced");
    assert.deepEqual(pending.body,{study_id:h.study.study_id,payload:{confirmation:true}});
    assert.equal(withdrawalCalls.length,1);
    assert.deepEqual(withdrawalCalls[0].body,pending.body.payload);
    assert.equal(withdrawalCalls[0].key,pending.keys.request);
    assert.equal(h.app.getSnapshot().state!.queue.find(q=>q.check_id===savedId)!.state,"blocked");
    assert.equal(h.app.getSnapshot().state!.queue.find(q=>q.check_id===savedId)!.error,"WITHDRAWAL_PENDING");
    assert.match(h.app.getSnapshot().message!,/pending request status|service outcome/i);
    trace.push({event:"offline-state",pending:clone(pending),membership:clone(membership),activeCapture:h.app.check!.attempts[0]!.status});
    // Restore only fictional service transport; replay same exact persisted request/key.
    globalThis.fetch = async(input,init)=>{
      const path = new URL(String(input)).pathname;
      if(path.endsWith("/withdrawals")) withdrawalCalls.push({path,body:JSON.parse(String(init?.body)),key:new Headers(init?.headers).get("Idempotency-Key")});
      return transport(input,init);
    };
    h.service.overrides.set(`/v1/studies/${h.study.study_id}/withdrawals`,()=>h.service.result({state:"withdrawn"}));
    await h.app.retryUploads();
    const accepted = h.app.getSnapshot().state!.queue.find(q=>q.id===pending.id)!;
    assert.equal(accepted.state,"synced");
    assert.deepEqual(accepted.body,pending.body);
    assert.deepEqual(accepted.keys,pending.keys);
    assert.equal(withdrawalCalls.length,2);
    assert.deepEqual(withdrawalCalls[1],withdrawalCalls[0]);
    const finalMembership=h.app.getSnapshot().state!.studies.find(s=>s.study_id===h.study.study_id)!;
    assert.equal(finalMembership.local_withdrawal_pending,false);
    assert.equal((finalMembership.consent as any).state,"withdrawn");
    assert.equal(h.app.getSnapshot().state!.queue.find(q=>q.check_id===savedId)!.state,"blocked");
    assert.equal(active,false);
    await assert.rejects(h.app.captureReader("ppg",false,currentInstruction(h.app,"cardiac")));
    trace.push({event:"accepted-state",queue:clone(accepted),membership:clone(finalMembership),withdrawalCalls,uploadsRemainBlocked:true});
    require("node:fs").writeFileSync(process.env.SEMANTICS_OUTPUT+"/offline-withdrawal-observations.json",JSON.stringify({status:"PASS",case_id:"OTGD-038-AND-STUDY-005-01",trace,limits:"Fictional native and HTTP boundaries; actual unchanged current controller/storage/queue/ApiClient/sync. No OS, physical stop, live backend, clinical or scientific claims."},null,2)+"\n");
  } finally {
    (h.app.device as any).captureAuthorized=previousCapture;
    await h.close();
  }
});
