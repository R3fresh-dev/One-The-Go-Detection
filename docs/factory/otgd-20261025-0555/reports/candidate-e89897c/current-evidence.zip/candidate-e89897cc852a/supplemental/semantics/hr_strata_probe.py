"""Declared fictional software probe; imports frozen current pipeline/test fixtures.
No data store, network, physical device, scientific admission or release authority.
"""
from pathlib import Path
from types import SimpleNamespace
import sys, json, hashlib, datetime, subprocess
R=Path('/workspace/One-The-Go-Detection')
O=Path(__file__).resolve().parent
sys.path[:0]=[str(R/'services/api'),str(R)]
from tests import test_model_evaluation as base
from tests import test_model_evaluation_cardiac as hr
from otgd.canonical import digest
m=base.m
results=[]
for adapter,personalized in [('otgd_esp32_adc_v1',False),('otgd_sparkfun_max32664_v1',False),('otgd_esp32_adc_v1',True),('otgd_sparkfun_max32664_v1',True)]:
    original=hr.cardiac_cohort.__wrapped__(base.cohort.__wrapped__(),SimpleNamespace(param=(adapter,personalized)))
    dataset,plan,split=original
    raw,analysis=dataset.model_dump(),plan.model_dump()
    # Sparse one-class routes and participant boundaries use current helper's declared labels.
    people=sorted(split['held_out_participants'])
    analysis['strata']['route']=['FICTIONAL-only-positive','FICTIONAL-only-negative','FICTIONAL-empty']
    analysis['strata']['population']=['FICTIONAL-single-participant','FICTIONAL-two-participants','FICTIONAL-other']
    analysis['uncertainty_policy']={'policy_id':'FICTIONAL-all-abstain-software-probe','method':'probability_band','lower':0.,'upper':1.}
    invalid_ids={split['session_ids'][p][0] for p in ('confirmatory','later_sessions')}
    for row in raw['sessions']:
        row['strata']['route']='FICTIONAL-only-positive' if row['endpoint']['value'] else 'FICTIONAL-only-negative'
        row['strata']['population']=('FICTIONAL-single-participant' if row['participant_ref']==people[0] else 'FICTIONAL-two-participants' if row['participant_ref'] in people[1:3] else 'FICTIONAL-other')
        if row['session_id'] in invalid_ids:
            # Deliberately corrupt immutable custody only in held-out rows, not training.
            row['cardiac_evidence']['authority_sha256']='0'*64
    fixture=base.rebind(m.Dataset.model_validate(raw),m.AnalysisPlan.model_validate(analysis))
    fixture_before=digest([fixture[0].model_dump(),fixture[1].model_dump(),fixture[2]])
    artifacts,training,report,evidence=base.pipeline(fixture)
    assert len(fixture[1].strata)==6
    assert set(artifacts)=={'cardiac_hr_only'}
    for bound in (training,report,evidence):
        assert bound['dataset_sha256']==digest(fixture[0].model_dump())
        assert bound['analysis_plan_sha256']==digest(fixture[1].model_dump())
        assert bound['split_plan_sha256']==digest(fixture[2])
    partitions={}
    for partition in ('confirmatory','later_sessions'):
        expected_ids=fixture[2]['session_ids'][partition]
        rows=[r for r in raw['sessions'] if r['session_id'] in expected_ids]
        output=evidence['row_predictions'][partition]['cardiac_hr_only']
        assert [r['session_id'] for r in output]==expected_ids
        assert {r['session_id'] for r in output if r['state']=='invalid'}==invalid_ids.intersection(expected_ids)
        assert sum(r['state']=='abstained' for r in output)==7
        assert all(r['predicted_positive'] is None for r in output)
        assert all(r['probability'] is None if r['session_id'] in invalid_ids else r['probability'] is not None for r in output)
        assert report[partition]['total']==8 and report[partition]['invalid']==1 and report[partition]['abstained']==7
        dimensions={}
        for dimension,categories in fixture[1].strata.items():
            groups=evidence['subgroups'][partition][dimension]
            assert set(groups)==set(categories)
            observations=[]
            for category in categories:
                group=groups[category]['cardiac_hr_only']; summary=group['metrics']; detail=group['details']
                members=sorted(r['session_id'] for r in rows if r['strata'][dimension]==category)
                invalid=len(set(members)&invalid_ids)
                expected={'total':len(members),'invalid':invalid,'valid':len(members)-invalid,'abstained':len(members)-invalid,
                    'positives':sum(r['endpoint']['value']==1 for r in rows if r['session_id'] in members),
                    'negatives':sum(r['endpoint']['value']==0 for r in rows if r['session_id'] in members)}
                assert group['session_ids']==members
                assert {key:summary[key] for key in expected}==expected,(adapter,personalized,partition,dimension,category)
                assert detail['invalid_rate']==(invalid/len(members) if members else None)
                assert detail['abstention_rate']==((len(members)-invalid)/len(members) if members else None)
                assert detail['predictive_values']['decision_coverage']==(0 if members else None)
                observations.append({'category':category,'session_ids':members,'observed':{key:summary[key] for key in expected},'expected':expected})
            totals={key:sum(o['observed'][key] for o in observations) for key in ('total','invalid','valid','abstained','positives','negatives')}
            assert totals=={'total':8,'invalid':1,'valid':7,'abstained':7,'positives':4,'negatives':4}
            assert sorted(s for o in observations for s in o['session_ids'])==expected_ids
            dimensions[dimension]={'totals':totals,'categories':observations}
        partitions[partition]=dimensions
    assert fixture_before==digest([fixture[0].model_dump(),fixture[1].model_dump(),fixture[2]])
    assert evidence['authority_granted'] is evidence['clinical_success_claimed'] is False
    assert evidence['paired_ablations']=={'confirmatory':{},'later_sessions':{}}
    label=adapter+('-personalized' if personalized else '-population')
    (O/(label+'.evidence.json')).write_text(json.dumps({'report':report,'evidence':evidence,'training':training},indent=2)+'\n')
    result={'variant':label,'result':'PASS','fixture_sha256':fixture_before,'dataset_sha256':digest(fixture[0].model_dump()),'analysis_plan_sha256':digest(fixture[1].model_dump()),'split_sha256':digest(fixture[2]),'invalid_ids':sorted(invalid_ids),'partitions':partitions}
    results.append(result)
    print(label, 'PASS: 2 partitions x 6 dimensions; each retains 8 total, 1 invalid, 7 abstained',flush=True)
paths=['tools/model_evaluation.py','services/api/tests/test_model_evaluation.py','services/api/tests/test_model_evaluation_cardiac.py','services/api/otgd/cardiac_authority.py','services/api/otgd/model_engine.py']
summary={'candidate':subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD'],text=True).strip(),'checked_utc':datetime.datetime.now(datetime.UTC).isoformat(),'case_ids':['OTGD-041-EVAL-002-04','OTGD-042-HR-AUTH-008-01'],'status':'PASS','source_sha256':{p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in paths},'assertion_scope':'Actual unchanged train/evaluate pipeline, original current fixture constructors; deliberate invalid custody and probability-band abstention, independently derived per-category counts in six frozen dimensions for both held-out partitions and four adapter/baseline variants.','limits':'Engineered fictional data only. No scientific/model admission, physical acquisition, clinical qualification, participant use, release or deployment authority.','variants':results}
(O/'hr-strata-results.json').write_text(json.dumps(summary,indent=2)+'\n')
