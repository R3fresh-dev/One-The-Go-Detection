from pathlib import Path
import re,json,hashlib
R=Path('/workspace/One-The-Go-Detection'); O=Path(__file__).resolve().parent
src=R/'apps/mobile/tests/acquisition.test.ts'
text=src.read_text()
# Preserve actual current assertions/helper bodies verbatim except absolute import resolution.
text=re.sub(r'(\bfrom\s+|\brequire\(\s*|\bimport\(\s*)([\"\'])(\.[^\"\']+)\2', lambda x:x[1]+x[2]+str((src.parent/x[3]).resolve())+x[2],text)
text+='\n'+(O/'offline_withdrawal_probe.fragment.ts').read_text()
(O/'current-acquisition-plus-probe.test.ts').write_text(text)
(O/'mobile-source-binding.json').write_text(json.dumps({'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'transformation':'Only current source import/require paths made absolute; unchanged current tests/helpers plus separately retained external probe fragment. Node test-name-pattern selects two current late-collection tests and one external offline active-capture probe.','probe_sha256':hashlib.sha256((O/'offline_withdrawal_probe.fragment.ts').read_bytes()).hexdigest()},indent=2)+'\n')
