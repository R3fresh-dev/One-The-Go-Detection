"""Execute current orchestration with mocked external mutations. No AWS is called."""
import contextlib
import copy
import hashlib
import io
import json
from pathlib import Path
from unittest.mock import patch

from deploy import orchestrate,platform,web_artifact

OUT=Path(__file__).resolve().parent
cfg={'environment':'qa','account':'123456789012','region':'us-east-2',
     'releaseId':'c'*40,'imageDigest':'sha256:'+'a'*64,
     'recoveryRequired':False,'activateServices':False}
old={'Cluster':'arn:aws:ecs:us-east-2:123456789012:cluster/fictional-probe',
     'ApiService':'fictional-api','WorkerService':'fictional-worker',
     'ApiTaskDefinition':'arn:aws:ecs:us-east-2:123456789012:task-definition/fictional-api:17',
     'WorkerTaskDefinition':'arn:aws:ecs:us-east-2:123456789012:task-definition/fictional-worker:23',
     'ReleaseId':'d'*40,'ImageDigest':'sha256:'+'b'*64}
snapshot=copy.deepcopy(old)
(OUT/'modeled-prior-target.json').write_text(json.dumps(snapshot,indent=2)+'\n')
release=OUT/'modeled-release.json'
release.write_text(json.dumps({'payload':{'image_digest':cfg['imageDigest']}})+'\n')
args=orchestrate.parser('qa').parse_args(['--config','fictional.json','--release',str(release),
    '--work-dir',str(OUT/'rollback-attempt'),'--gate-evidence','fictional-gates.json',
    '--trusted-public-key','fictional-public.pem','--signing-key','fictional-private.pem'])
calls=[]
def stage(operation,*a,**kw):
    calls.append(operation)
    if operation=='migrate':raise RuntimeError('fictional modeled migration exit 1')
    if operation=='bootstrap':kw['output'].write_text(json.dumps({'operation':operation,'status':'fixture_success'})+'\n')
output=io.StringIO();error=None
with patch.object(platform,'read_config',return_value=cfg),patch.object(platform,'require_clean_source'),\
     patch.object(platform,'require_trusted_signer'),patch.object(platform,'verify_gate_file'),\
     patch.object(platform,'preflight'),patch.object(platform,'run'),\
     patch.object(platform,'require_release',return_value={}),\
     patch.object(platform,'stack_outputs',return_value=old),patch.object(platform,'quiesce') as quiesce,\
     patch.object(orchestrate,'invoke',side_effect=stage),patch.object(web_artifact,'publish') as publish,\
     patch.object(web_artifact,'build') as build,contextlib.redirect_stderr(output):
    try:orchestrate.deployment(args,'qa')
    except RuntimeError as exc:error=str(exc)
    quiesce.assert_called_once()
    publish.assert_not_called();build.assert_not_called()
journal_path=next((OUT/'rollback-attempt').rglob('deployment-state.json'))
journal=json.loads(journal_path.read_text())
# Inspect only files emitted by the real orchestrator, not the supplied fixture.
artifacts={str(p.relative_to(journal_path.parent)):p.read_text() for p in journal_path.parent.iterdir() if p.is_file()}
exact_previous_references={key: any(value in text for text in artifacts.values())
                           for key,value in snapshot.items() if key in ('ApiTaskDefinition','WorkerTaskDefinition','ReleaseId','ImageDigest')}
result={'candidate':'e89897cc852a111b131eaf5c2caaf163ef201a48',
        'boundary':'Current real deployment orchestration and StageJournal; ALL cloud/build/signing/mutation boundaries patched. No deployment executed.',
        'modeled_previous_target':snapshot,'external_operation_calls':calls,'exception':error,
        'journal_path':str(journal_path),'journal':journal,'artifacts':list(artifacts),
        'assertions':{'migration_stops_before_activation_web_build_or_publication':calls==['registry','deploy-stopped','bootstrap','migrate'],
                      'journal_records_failed_migrate':journal['failed_stage']=='migrate' and journal['status']=='failed',
                      'no_inferred_rollback':journal['rollback_executed'] is False,
                      'input_prior_mapping_not_mutated':old==snapshot},
        'required_previous_target_recorded_in_emitted_state':exact_previous_references,
        'all_exact_prior_target_references_recorded':all(exact_previous_references.values()),
        'limits':['This is a bounded mocked-external-backend execution, not live AWS acceptance.',
                  'Unchanged caller input mapping does not prove cloud rollback-target retention.',
                  'No actual migration task, live task-definition retention, rollback, restoration, or promotion was executed.']}
(OUT/'rollback-probe.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2));print(output.getvalue())
assert all(result['assertions'].values())
# Missing exact prior targets is reported, never converted to a passing clause.
