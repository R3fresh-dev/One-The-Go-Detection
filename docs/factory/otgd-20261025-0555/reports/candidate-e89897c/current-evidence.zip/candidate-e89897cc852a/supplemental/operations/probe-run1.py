"""Frozen-source, isolated-process supplemental evidence. No repo writes/cloud calls."""
import contextlib
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request

ROOT=Path('/workspace/One-The-Go-Detection')
OUT=Path(__file__).resolve().parent
PYTHON=ROOT/'services/api/.venv/bin/python'
BASE={'PATH':'/usr/bin:/bin','PYTHONPATH':str(ROOT/'services/api'),
      'PYTHONDONTWRITEBYTECODE':'1','PYTHONUNBUFFERED':'1',
      'AWS_EC2_METADATA_DISABLED':'true','TMPDIR':str(OUT)}

def free_socket():
    sock=socket.socket();sock.bind(('127.0.0.1',0));return sock

def get(port,path,headers=None):
    try:
        with urllib.request.urlopen(urllib.request.Request(f'http://127.0.0.1:{port}{path}',headers=headers or {}),timeout=.3) as r:
            return {'status':r.status,'body':r.read(65536).decode()}
    except urllib.error.HTTPError as e:
        return {'status':e.code,'body':e.read(65536).decode()}
    except (urllib.error.URLError,TimeoutError,ConnectionError) as e:
        return {'status':None,'error':type(e).__name__}

def probe(name,settings,live=False,forbidden=()):
    bound=free_socket();port=bound.getsockname()[1];bound.close()
    env={**BASE,**settings}
    command=[str(PYTHON),'-B','-m','uvicorn','otgd.main:app','--host','127.0.0.1','--port',str(port),'--no-access-log']
    observations=[];start=time.monotonic()
    with (OUT/(name+'.stdout')).open('w') as stdout,(OUT/(name+'.stderr')).open('w') as stderr:
        child=subprocess.Popen(command,cwd=OUT,env=env,stdout=stdout,stderr=stderr)
        stopped=False
        try:
            while time.monotonic()-start<15:
                response=get(port,'/health/live');observations.append(response)
                if response['status'] is not None or child.poll() is not None:break
                time.sleep(.05)
            if live and child.poll() is None and observations[-1]['status'] is not None:
                pairs=[]
                for _ in range(2):
                    pairs.append({'liveness':get(port,'/health/live'),'readiness':get(port,'/health/ready')})
                protected=[get(port,'/v1/me'),get(port,'/v1/me',{'Authorization':'Bearer fictional-invalid-token'})]
            else:pairs=[];protected=[get(port,'/health/ready'),get(port,'/v1/me')]
            exit_before_cleanup=child.poll()
        finally:
            if child.poll() is None:
                stopped=True;child.terminate()
                try:child.wait(timeout=5)
                except subprocess.TimeoutExpired:child.kill();child.wait(timeout=5)
            else:child.wait()
    logs=(OUT/(name+'.stdout')).read_text()+(OUT/(name+'.stderr')).read_text()
    result={'name':name,'command':command,'cwd':str(OUT),'supplied_environment':env,
            'inherited_environment':False,'pid':child.pid,'port':port,
            'elapsed_seconds':time.monotonic()-start,'exit_before_cleanup':exit_before_cleanup,
            'exit_status':child.returncode,'terminated_own_child_only':stopped,
            'startup_liveness_attempts':observations,'health_pairs':pairs,'protected_or_readiness_probes':protected,
            'forbidden_sentinels_absent':all(v not in logs for v in forbidden),
            'no_http_accepted':all(v['status'] is None for v in observations+protected)}
    if live:
        result['assertions']={'same_process_alive_200_ready_503':len(pairs)==2 and all(p['liveness']['status']==200 and json.loads(p['liveness']['body'])=={'status':'alive'} and p['readiness']['status']==503 and json.loads(p['readiness']['body'])['code']=='SERVICE_UNAVAILABLE' for p in pairs),
                              'unauthenticated_and_invalid_token_rejected':all(r['status']==401 for r in protected),
                              'no_secret_logged':result['forbidden_sentinels_absent']}
    else:
        result['assertions']={'startup_nonzero_exit_before_listen':exit_before_cleanup not in (None,0) and result['no_http_accepted'],
                              'no_secret_logged':result['forbidden_sentinels_absent']}
    (OUT/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'probe':name,'assertions':result['assertions'],'exit':child.returncode}),flush=True)
    assert all(result['assertions'].values()), name
    return result

def main():
    prod={'OTGD_ENVIRONMENT':'prod','OTGD_DEPLOYMENT_ACCOUNT':'123456789012',
          'OTGD_SOURCE_REVISION':'e89897cc852a111b131eaf5c2caaf163ef201a48',
          'OTGD_DATABASE_SSLMODE':'verify-full','OTGD_DATABASE_SSLROOTCERT':'/fictional/not-read-ca.pem',
          'OTGD_ISSUER':'https://identity.example.invalid','OTGD_JWKS_URL':'https://identity.example.invalid/keys',
          'OTGD_API_ORIGIN':'https://api.example.invalid','OTGD_IDENTITY_ORIGIN':'https://identity.example.invalid',
          'OTGD_JOURNAL_KMS_KEY_ID':'fictional-journal-key','OTGD_STORAGE_KMS_KEY_ID':'fictional-data-key',
          'OTGD_USER_POOL_ID':'fictional-pool','OTGD_QUEUE_URL':'https://sqs.example.invalid/queue',
          'OTGD_DLQ_URL':'https://sqs.example.invalid/dlq','OTGD_TOMBSTONE_KEY':'b'*64}
    probe('prod-emulator-rejected',{**prod,'OTGD_AWS_ENDPOINT_URL':'http://127.0.0.1:4566'})
    probe('prod-local-identity-rejected',{**prod,'OTGD_ISSUER':'http://127.0.0.1:8081'})
    # Missing reference validation precedes boto3.client; no cloud request is made.
    sentinel='FICTIONAL-OMISSION-PROBE-PASSWORD-DO-NOT-LOG'
    probe('missing-database-secret-rejected',{
        'OTGD_ENVIRONMENT':'prod','OTGD_SERVERLESS_MODE':'true','OTGD_DEPLOYMENT_ACCOUNT':'123456789012',
        'OTGD_TOMBSTONE_SECRET_ARN':'arn:aws:secretsmanager:us-east-2:123456789012:secret:fictional-tombstone',
        'OTGD_DATABASE_PASSWORD':sentinel},forbidden=(sentinel,))
    db=free_socket()  # Bound but never listening: actual local connection refusal.
    try:
        probe('unavailable-database-live-readiness',{
            'OTGD_ENVIRONMENT':'local','OTGD_TOMBSTONE_KEY':'c'*64,
            'OTGD_DATABASE_HOST':'127.0.0.1','OTGD_DATABASE_PORT':str(db.getsockname()[1]),
            'OTGD_DATABASE_NAME':'fictional_probe_db','OTGD_DATABASE_USER':'fictional_probe_user',
            'OTGD_DATABASE_PASSWORD':'FICTIONAL-UNAVAILABLE-DB-PASSWORD'},live=True,
            forbidden=('FICTIONAL-UNAVAILABLE-DB-PASSWORD',))
    finally:db.close()

if __name__=='__main__':main()
