from pathlib import Path
import hashlib,json,subprocess,datetime,re
R=Path('/workspace/One-The-Go-Detection');O=Path(__file__).resolve().parent;X=O.parents[1]
C='e89897cc852a111b131eaf5c2caaf163ef201a48';FP='1855fca1465dc9e19c006cba7b749967ebc28c839282b42c56079ca6159c19a7'
def git(*args):return subprocess.check_output(['git','-C',str(R),*args])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==C
assert git('status','--short')==b''
fingerprint=hashlib.sha256();count=0
for name in sorted(set(x for x in git('ls-files','-z','--cached','--others','--exclude-standard').split(b'\0') if x)):
    path=R/name.decode()
    if path.is_file(): fingerprint.update(name+b'\0'+path.read_bytes());count+=1
assert fingerprint.hexdigest()==FP
hr=json.loads((O/'hr-strata-results.json').read_text());assert hr['status']=='PASS' and len(hr['variants'])==4
assert len([1 for v in hr['variants'] for p in v['partitions'].values() for d in p])==48
mobile=(O/'mobile.raw.log').read_text()
assert re.search(r'pass 3\b',mobile) and re.search(r'fail 0\b',mobile)
assert 'late fictional collection receipt across withdrawal' in mobile and 'late fictional collection receipt across workspace switch' in mobile
assert json.loads((O/'offline-withdrawal-observations.json').read_text())['status']=='PASS'
paths=['apps/mobile/src/controller.ts','apps/mobile/src/services/sync.ts','apps/mobile/src/core/workspaceScope.ts','apps/mobile/tests/acquisition.test.ts','apps/mobile/tests/support/customer.ts','apps/mobile/tests/support/runtime.cjs','tools/model_evaluation.py','services/api/tests/test_model_evaluation.py','services/api/tests/test_model_evaluation_cardiac.py','services/api/otgd/cardiac_authority.py','services/api/otgd/model_engine.py']
paths=[p for p in paths if (R/p).is_file()]
# Preserve exact current assertions and relevant control flow for independent review.
src=(R/'apps/mobile/tests/acquisition.test.ts').read_text().splitlines()
(O/'current-late-collection-assertions.txt').write_text('\n'.join(f'{i+1}: {line}' for i,line in enumerate(src) if 922<=i<1003)+'\n')
commands=[{'id':'hr-initial-runner-discovery','command':f'PYTHONDONTWRITEBYTECODE=1 OTGD_ENVIRONMENT=test OTGD_DATABASE_URL=sqlite:// {R}/.venv/bin/python {O}/hr_strata_probe.py','exit_code':1,'log':'hr-strata.initial-runner-unavailable.log','outcome':'Root venv lacked pytest; no pipeline ran and no source defect. Used existing API venv without installation.'},
{'id':'hr-strata','command':f'PYTHONDONTWRITEBYTECODE=1 OTGD_ENVIRONMENT=test OTGD_DATABASE_URL=sqlite:// {R}/services/api/.venv/bin/python {O}/hr_strata_probe.py','exit_code':0,'log':'hr-strata.raw.log','outcome':'Four current HR fixture variants, actual train/evaluate functions; 48 partition/dimension conjunctions plus every prespecified category passed.'},
{'id':'mobile-prepare','command':f'PYTHONDONTWRITEBYTECODE=1 python {O}/prepare_mobile_probe.py','exit_code':0,'outcome':'Current helpers/assertions import resolution only; separately preserved external probe appended.'},
{'id':'mobile','command':f"TSX_DISABLE_CACHE=1 SEMANTICS_OUTPUT={O} node --import {R}/apps/mobile/node_modules/tsx/dist/loader.mjs --test --test-name-pattern='late fictional collection receipt|supplemental offline active' {O}/current-acquisition-plus-probe.test.ts",'exit_code':0,'log':'mobile.raw.log','outcome':'Three selected software checks passed; zero fail/cancel/skip.'},
{'id':'final-evidence-binding','command':f'PYTHONDONTWRITEBYTECODE=1 python {O}/finalize_evidence.py','exit_code':0,'outcome':'Exact HEAD/source fingerprint and clean tracked/untracked worktree confirmed; parsed successful raw/structured observations.'}]
(O/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
case_results=[{'case_id':cid,'residual_evidence_status':'VERIFIED_SOFTWARE_RESIDUAL','evidence':['hr-strata-results.json','hr-strata.raw.log','hr_strata_probe.py'],'observed':'Both confirmatory and later_sessions partitions, all six dimensions and every category independently reconcile row identity, total/invalid/valid/abstained/class counts. Each dimension retains total=8, invalid=1, valid=7, abstained=7; four actual adapter/population-personalized fixture variants; original immutable input hashes retained and authority_granted/clinical_success_claimed false.'} for cid in ['OTGD-041-EVAL-002-04','OTGD-042-HR-AUTH-008-01']]
case_results += [{'case_id':'OTGD-038-AND-STUDY-005-01','residual_evidence_status':'VERIFIED_SOFTWARE_RESIDUAL','evidence':['offline-withdrawal-observations.json','offline_withdrawal_probe.fragment.ts','mobile.raw.log'],'observed':'Actual captureReader operation entered declared fictional reader boundary after real authorization flow; offline withdraw invoked device cancellation WITHDRAWAL, ended persisted attempt invalid with null HR; exact privacy intent body/idempotency key retained not synced, consent remained active with local_withdrawal_pending true; later same-body/key fictional accepted response set membership withdrawn/pending false while real verified saved-check upload stayed blocked. Restart attempt refused.','limits':'Server response and device cancellation are declared doubles. Existing server-side authoritative withdrawal/upload checks remain separate evidence; this probe does not assert live backend, hardware or OS execution.'},
{'case_id':'OTGD-040-SALCOL-007-02','residual_evidence_status':'VERIFIED_SOFTWARE_RESIDUAL','evidence':['current-late-collection-assertions.txt','mobile-source-binding.json','mobile.raw.log','current-acquisition-plus-probe.test.ts'],'observed':'Both exact existing current-controller tests execute accepted fictional POST collection response held unresolved even when fetch ignores AbortSignal. Withdrawal preserves original key/body/snapshot with no receipt; workspace switch creates a different account/check with not_collected sample and no old check. After release original promise fails, full fenced workspace including queue remains byte-structure equal, check ID unchanged, no new calls/hardware, empty saliva.'}]
summary={'role':'Independent bounded semantic evidence executor; not PM or final app approver','candidate':C,'source_fingerprint_sha256':FP,'source_fingerprint_file_count':count,'run_id':'otgd-20261025-0555','recorded_utc':datetime.datetime.now(datetime.UTC).isoformat(),'status':'BOUNDED_SOFTWARE_PROBES_PASS','repository_status_short':'','source_sha256':{p:sha(R/p) for p in paths},'decision_acknowledgments':{'D008v3':'AFFECTED: exact frozen source and source hashes preserved','D010v2':'AFFECTED: correction round 2/2; no source fixes, no defects reproduced','D006v10':'AFFECTED: retained runtime/data/dependencies unchanged','D006v11':'AFFECTED: per-process fixtures; output only assigned semantics directory'},'cases':case_results,'executions':{'hr':{'exit_code':0,'variants':4,'partitions_per_variant':2,'dimensions_per_partition':6,'dimension_reconciliations':48},'mobile':{'exit_code':0,'tests':3,'pass':3,'fail':0,'cancelled':0,'skipped':0}},'remaining_blockers_in_assigned_residual_scope':[],'approval':'No APP_VERIFIED/RELEASE_READY or scientific/model/participant-use qualification granted. Final verification specialist and independent council assess these artifacts with all other gates.','limits':['Fictional engineering fixtures; no hardware/installed OS/clinical study claims.','These are supplemental probes; do not substitute for mandatory full local/CI gates or coverage.','No deploy, paid service, merge, participant use, service/container/volume/dependency/branch changes.','Backend and native boundaries are doubled in mobile tests; actual unchanged controller/domain/serialized storage/ApiClient/sync execute.','Initial root Python venv lacked pytest; available current API venv succeeded, without installation.']}
(O/'results.json').write_text(json.dumps(summary,indent=2)+'\n')
(O/'report.md').write_text(f'''Role: independent bounded semantic evidence executor, separate from author/PM/final approver.
Candidate: {C}
Fingerprint: {FP}
Run: otgd-20261025-0555. Correction 2/2; recovery 0/3.

All four assigned software residual clauses have current executed supplemental evidence. HR actual train/evaluate pipeline passed four adapter/baseline variants and 48 partition/dimension reconciliations. Every dimension independently retains eight total, one invalid, seven valid/abstained rows with exact category memberships. Current immutable custody hashes and false external authority stay explicit.

Mobile runner passed three tests, zero failures/cancellations/skips: both unchanged current late collection response tests (withdrawal and workspace switch), plus the external offline active-reader withdrawal probe. Withdrawal cancels active fictional device work locally, persists invalid/null measurement and exact pending body/key, retains truthful local-pending versus server membership, and later replays the same intent. A real integrity-verified frozen check queue remains blocked after the fictional service confirmation. Late collection acceptance cannot alter the full fenced workspace, specimen projection, queue, identity or selected replacement check.

No source defects were reproduced; no fixes or repository writes were made. HEAD/fingerprint still match the freeze and git status is clean. Initial root venv lacked pytest; the existing API venv completed successfully without installing anything.

Evidence: results.json (per-case scope/assertions), commands.json (exact invocations/exits), hr-strata-results.json (48 reconciliations and every category), four *.evidence.json (actual report/training/evaluation output), mobile.raw.log, offline-withdrawal-observations.json, current-late-collection-assertions.txt, mobile-source-binding.json, retained external probe scripts.

Decision impacts: D008 v3, D010 v2, D006 v10/v11 AFFECTED and applied as acknowledged to PM. Source frozen; correction limit held; services/data/dependencies/branches preserved.

Scope limits: fictional software evidence only. Mobile device/HTTP/native boundaries are declared doubles; the actual unchanged controller/domain/serialized storage/ApiClient/sync execute. No physical stop, installed OS, live service, scientific or clinical qualification is implied. These supplements do not replace mandatory full local/CI gates, independent verification, per-spec reviews or council approval. No APP_VERIFIED/RELEASE_READY self-approval. No remaining blockers in this assigned bounded residual scope.
''')
manifest={p.name:sha(p) for p in sorted(O.iterdir()) if p.is_file() and p.name!='artifact-manifest.json'}
(O/'artifact-manifest.json').write_text(json.dumps({'candidate':C,'sha256':manifest},indent=2)+'\n')
print(json.dumps({'status':summary['status'],'head':C,'fingerprint':fingerprint.hexdigest(),'clean_repository':True,'hr_dimension_reconciliations':48,'mobile_tests_passed':3,'results':str(O/'results.json')}))
