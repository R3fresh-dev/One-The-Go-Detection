# Independent final-candidate UX confirmation — evidence update pending

**Verdict BLOCKED**, IMPLEMENTATION scope, candidate `e89897cc852a111b131eaf5c2caaf163ef201a48`. No unresolved demonstrated UX source defect remains from this bounded review. All47 provisional decisions are BLOCKED pending current complete gates/CI and exact-case evidence. Native OS/accessibility prerequisites remain explicit. This is not global app completion, scientific approval, native qualification, release readiness or final council approval.

Reviewer `/root/replacement_ux`, independent of authors/specification writers. Explicitly configured OpenAI `gpt-6.1-sol/high`; independent runtime model query unavailable. Correction2/2, recovery0/3. Actual ACK sent for D008v3 and D010v2 AFFECTED, D006v10/v11 NOT_AFFECTED to UX actions, with preserved D001–D009 software/measurement/fictional/authority limits. No repository edits, tests, browser/runtime probes, Docker/service operations or additional agents. Owned output is this new external reviews/ux directory; prior reports preserved.

HEAD independently matches candidate. All47 canonical SHA256 hashes freshly recomputed and equal new binding and previous independent review; no spec silently excluded. `source-manifest.json` records current hashes for inspected source/assertions and identifies source unchanged since prior inspection. The supplied complete source fingerprint is `1855fca1465dc9e19c006cba7b749967ebc28c839282b42c56079ca6159c19a7`; I verified HEAD/canonical/inspected file hashes, not a new runtime image or complete fingerprint execution. The candidate binds H image `sha256:f6c164a1739b3470c54af0ecf8d3db548fe9b7ccc3fba9dc328949e557f240c0`; packaging remains local software evidence.

## Independent finding closure

**UX-R001/UI003: corrected in source and meaningful focused execution.** I read the actual device-red.log failures: the framed signed peripheral test returns connected=false instead of true, and the healthy-reader presentation test fails the same branch. home-device-red.log records actual Home JSX displaying unavailable handshake and unconditional all-human-unavailable copy. These are real assertion failures, not screenshot interpretation.

Current `core/devicePresentation.ts:125` handles healthy connected_reader/prototype_sensor/current boot/reason-null, distinguishes unbound identity from service-bound reader and returns Signed reader connection. `ui/device-summary.tsx` uses view.badge instead of Synthetic only, and Home/Device reuse AcquisitionAvailability. `ui/manage.tsx` diff is confined to its import and DeviceScreen channel Facts. The capability presenter checks active matching identity/owner/generation, online/non-preview, channel availability/software/authorization and configurations strictly unexpired at supplied now. It never takes connection or binding as authority input. It says conditional/fresh Start required, with exact scope/consent/adapter/scientific warning. Simulator remains fictional; unknown/denied/expired/offline/mismatched observations remain unavailable.

`tests/device-presentation.test.ts` exercises simulator/unbound/bound/current/revoked/expired/disconnected/rebooted/mismatched/generation/offline and expiry equality. The actual framed physical fixture retains the original capture-before-binding refusal; presentation does not establish actual physical eligibility. `e2e/components.spec.ts:56` explicitly compares Home and Device for each controlled state;130 advances the browser clock to exact expiry while Home is mounted, verifies conditional availability disappears, then verifies Device's expired state. focused-browser-green.log records these exact tests passing at both viewports. Their provider/peripheral data are named software fixtures; real BLE/OS/hardware qualification remains absent. The old source finding is closed, with final combined-source gate adoption still pending.

**Mounted HR result/manual recovery: corrected.** Actual hr-mounted-red2.log records both viewports failing expected2 GETs/received1; hr-manual-red.log records expected>0/received0. The earlier invalid no-queue fixture is not accepted as product RED. ResultScreen at `ui/checks.tsx:1680` now owns the view before HR availability and includes saved result digest in dependencies; exact result-byte changes replace view admission. `controller.ts:4070` can establish a missing view only for the same active Result check, while respecting a newer UI-owned token.

Current browser169 starts both pending and locally saved measurement states, delivers first HR through actual AppController.tick/SyncEngine with controlled HTTP, retains same check ID/epoch, asserts withheld after first response, waits for the separate second current-display GET, reveals81.8 only after match and asserts no GET loop. Browser211 verifies explicit mounted pending manual refresh recovery. The actual named focused GREENs passed both viewports. Existing403/422/offline/mismatch/leave/reopen/background/account/generation/newest-request and separate export admission assertions remain. This is current-display authorization behavior, with immutable original evidence and no invented scientific TTL.

**Returned OAuth callback: correction confirmed in the UX account-switch boundary.** `services/auth.ts:35` compares original returned target bytes with the selected compiled callback and requires exactly one code and state matching request/SDK before exchange. `tests/auth-callback.test.ts` runs actual AppController/AuthManager with explicit platform/SDK/HTTP doubles; wrong scheme/host/port/path/suffix/userinfo/fragment/other compiled callback and malformed/duplicate/mismatched query require zero HTTP, unchanged identities and generation. Exact web/Android/iOS callbacks and fresh retry still exchange. callback-red.log/red-native-observation.json establish original actual app exchange/account-switch path at the software boundary; auth-release.xml/log record current named successes, including replay and coordinated actual loopback401 recovery. Native OS browser routing/cancellation and deployment issuer policy remain separate.

**Numeric research cloud export: correction confirmed in the exact selected-record journey.** I inspected `services/api/otgd/report_revisions.py:247/816` and `tests/test_current_result_readback.py:129`: generic validation still checks immutable linked result/current HR authority, while exact empty companion index is available only when no report/result companion exists. Administrative revision _base remains narrower.

Actual focused RED records numeric current HR and nonHR export503 REPORT_REVISION_INTEGRITY. Current exact positive cases require actual authenticated GET200, export202, worker completion, download200, unchanged full numeric result, equality of snapshot/context/manifest/attempts/instruction/collection/abandonment/alcohol, exact selected session, member digest/size and no fabricated revision. Focused GREEN XML/summary records both positives. Controls explicitly retain administrative refusal, orphan report/result companion refusal, legacy422 and numeric/abstained current HR request/build/commit/download retirement refusals. SQLite/object-store and fictional registry fixtures are named; this is no substitute for current live PostgreSQL/LocalStack gates or scientific authority.

**Initial UX001/UX002 and related UI/product corrections remain source-confirmed.** Verified result labels distinguish measurement/invalid/inconclusive/research/abstention independently of transport; onboarding explains measurement defaults and separate study/model authority; exact uncertainty policy/band is supplied, never invented. Route-heading/dialog/trigger focus, newer-user-focus cancellation, system/user motion and pressed destructive contrast retain source/assertions. The old accessibility helper/theme/component source hashes are unchanged; new component/raw full-browser author log preserves the named focus/motion/contrast/notice/profile/privacy/raw cases. No whole-app accessibility inference is made from those cases. TalkBack/VoiceOver/native200%text/browser cancellation/native modal lifecycle remain unexecuted prerequisites.

## Coverage and evidence limits across all47

The prior independent UX journey assessment remains the detailed baseline for unchanged source: guest and authenticated guided measurement, separate notice/context/study/raw choices, unavailable native reaction in browser, optical permission/preview, BLE denial/disconnect/reboot, local save before explicit eligible upload, default-off retry, lost-finalization/deletion acknowledgment, guarded conflict readback/linked correction, exact history/export, scoped local clear versus cloud deletion, retention/cleanup status, independent approvals, operator recovery and accurate preview/cloud/store delivery claims. Its report and JSON are hash-bound in the new evidence manifest. The all47 canonical specs and shared dependencies were reconciled against the final diff; changed auth/controller/Result/device presentation and generic export paths were specifically rereviewed above.

No source changes touched the prior raw-recordings spec/tests or focus/theme modules. The final manage.tsx diff does not change Settings/privacy/raw flows. Local export service/sharing functions retain independent preassembly and final-release current HR reads; display admission remains unusable as export authority. Frozen context, new replacement identities, guest separation, missingness, historical times and physiological/chemical/alcohol claim limits remain in force. The future fuel-cell breath-alcohol mg/L channel remains distinct, unavailable absent independent hardware/calibration authority, with no BAC conversion or driving clearance.

Actual evidence hashes are in `evidence-manifest.json`; source hashes in `source-manifest.json`; individual closure in `finding-closure.json`. Author80browser cases,394mobile cases,99focused auth and21focused export are inspected execution artifacts, **not final gates or blanket per-case acceptance**. Exact assertions above establish narrow behavior only. Historical782 baseline statuses remain historical; PARTIAL is not a source-bug count. Meaningful shared assertions are accepted without demanding duplicate test names.

At this snapshot current gate-process.json reports running and final-gates.log is not a completed7gate receipt. No current all14CI tree-bound result or complete782-case final reconciliation was supplied. Therefore no PASS. Native OS/accessibility/storage/permission/share/camera/BLE/real task input interruption evidence remains absent where required. Hardware/calibration/clinical/study and actual cloud/store deployment remain external prerequisites, not source defects or relabeled exclusions.

## Per-spec provisional dispositions

Each row has exact canonical path/SHA256, candidate, identity, IMPLEMENTATION scope, supporting manifest hashes and limits in `per-spec-decisions.json`. G = current gates/CI/exact-case evidence pending; N = applicable native OS/accessibility execution unavailable. No unresolved demonstrated software finding is assigned to any row.

| Spec | Journey | Decision | Holds |
|---|---|---|---|
| OTGD-001 | Full normative register: measurement default, source/claims, one-collection/one-task lineage, optional profile, alcohol separation, privacy and recovery; applied current amendment precedence. | BLOCKED | G,N |
| OTGD-002 | Dashboard admitted scope and fictional provenance. | BLOCKED | G |
| OTGD-003 | Save before upload, historical research navigation and missingness. | BLOCKED | G |
| OTGD-004 | Historical state, qualifier, time and admitted research scope. | BLOCKED | G |
| OTGD-005 | Guest versus research onboarding and independent notice. | BLOCKED | G |
| OTGD-006 | Verified research presentation versus ordinary null scores. | BLOCKED | G |
| OTGD-007 | Environment and account capability presentation. | BLOCKED | G |
| OTGD-008 | Research evaluation reports: genuine calculation versus externally unverified authority; no scientific claim adopted. | BLOCKED | G |
| OTGD-009 | Research admission, abstention and authenticated historical endpoint display. | BLOCKED | G |
| OTGD-010 | Separate exact raw-export purpose, notice, selected IDs, retention and share-copy limits. | BLOCKED | G |
| OTGD-011 | Operator reviewability, independent principals, rollback default and truthful capabilities. | BLOCKED | G |
| OTGD-012 | Conditional optical start, passive preview distinction, privacy stop and ROI opt-in. | BLOCKED | G,N |
| OTGD-013 | Signed reader identity/trust distinction, encrypted BLE and independent transport stop. | BLOCKED | G,N |
| OTGD-014 | Browser customer access, exact origins, navigation and honest release status. | BLOCKED | G |
| OTGD-015 | Cloud operator plan/apply, bounded recovery receipts and independent admission. | BLOCKED | G |
| OTGD-016 | Recovery fail-closed boundaries and retained deletion barriers. | BLOCKED | G |
| OTGD-017 | Isolated fictional preview, no account/acquisition services and honest persistence. | BLOCKED | G |
| OTGD-018 | Raw recording/upload separation, exact notice, local stop and independent cleanup status. | BLOCKED | G,N |
| OTGD-019 | Separate unavailable breath channel, mg/L/censoring, time, fictional data and no combined clearance. | BLOCKED | G |
| OTGD-020 | Fixed environments, bounded startup/recovery and truthful verification status. | BLOCKED | G,N |
| OTGD-021 | Home start/resume, device readiness, workspace races and accessible navigation. | BLOCKED | G,N |
| OTGD-022 | Deliberate export source/scope and explicit sharing, expiry and cleanup. | BLOCKED | G,N |
| OTGD-023 | BLE discovery/permission/radio denial, association, verified binding, disconnect/forget recovery. | BLOCKED | G,N |
| OTGD-024 | Optional ECG and declared versus actual electrical state; unavailable human ECG remains explicit. | BLOCKED | G,N |
| OTGD-025 | Camera preview/permission/lifecycle and conditional optical units/timing. | BLOCKED | G,N |
| OTGD-026 | Frozen context, eight-stage guided check, retained attempts, cancel/save/upload and parity. | BLOCKED | G,N |
| OTGD-027 | Pulse source/quality/contact/stale state and independent acquisition timing. | BLOCKED | G,N |
| OTGD-028 | Local/remote history, exact selection, immutable lineage and faithful states. | BLOCKED | G,N |
| OTGD-029 | Local-first storage, explicit queueing, lost acknowledgment replay and account generation. | BLOCKED | G,N |
| OTGD-030 | First-run explicit guest/account entry, versioned notice and no permission prompt on entry. | BLOCKED | G,N |
| OTGD-031 | Separate local clear/cloud deletion/account deletion, extra unsynced confirmation and durable pending intent. | BLOCKED | G,N |
| OTGD-032 | Optional profile, unit conversion, first-error focus, drafts/conflicts and frozen context. | BLOCKED | G,N |
| OTGD-033 | Native reaction instructions, practice/scored split, unavailable browser capture and interruption/retry semantics. | BLOCKED | G,N |
| OTGD-034 | Measurement/research/invalid/inconclusive states, missingness, historical time and separate delivery state. | BLOCKED | G,N |
| OTGD-035 | One saliva collection, quantity/qualifier/units, original report and delayed lab status. | BLOCKED | G,N |
| OTGD-036 | Functional settings, no-prompt permission status/recovery, diagnostics, appearance and accessibility. | BLOCKED | G,N |
| OTGD-037 | PKCE browser sign-in, cancel/unlock/account isolation, explicit logout and remote-revocation uncertainty. | BLOCKED | G,N |
| OTGD-038 | Exact consent and invitation, withdrawal, fresh capture admission and truthful study absence. | BLOCKED | G,N |
| OTGD-039 | Exact approved participant instructions, declaration boundaries, fresh acknowledgment and monotonic rest. | BLOCKED | G,N |
| OTGD-040 | Governed lab collection, specimen lineage, pending analysis and independent staff import. | BLOCKED | G,N |
| OTGD-041 | Prespecified matched evaluation / HR variant and truthful absent comparisons. | BLOCKED | G |
| OTGD-042 | Restricted cardiac timing authority and historical qualification limits. | BLOCKED | G |
| OTGD-043 | Selected vendor source/quality/freshness and software versus physical qualification. | BLOCKED | G,N |
| OTGD-044 | Private route/security header verification and bounded byte receipts. | BLOCKED | G |
| OTGD-045 | Exact CNAME preview/atomic create/no-op and bounded operator inputs. | BLOCKED | G |
| OTGD-046 | Fictional browser preview manifest, verified readiness and hosting boundaries. | BLOCKED | G |
| OTGD-047 | Store plan/build/submit/status, genuine signed artifact, uncertain submission and encrypted handoffs. | BLOCKED | G,N |

Final evidence update is required after PM supplies completed current gates/CI and exact case artifacts. That read-only confirmation is pending, not denied. Required native OS execution remains unexecuted because no installed target evidence was supplied. No action has an uncertain external outcome. Correction budget is exhausted; any newly demonstrated defect would require explicit NEEDS_HUMAN, not an automatic third edit round.
