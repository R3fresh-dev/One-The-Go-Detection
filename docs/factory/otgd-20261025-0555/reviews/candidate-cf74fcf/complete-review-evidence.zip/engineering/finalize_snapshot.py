import json,pathlib,hashlib,datetime,xml.etree.ElementTree as ET
O=pathlib.Path(__file__).parent;R=pathlib.Path('/workspace/One-The-Go-Detection');C=O.parent.parent
p=O/'per-spec-decisions.json';d=json.loads(p.read_text())
def ref(p):
 p=pathlib.Path(p);p=p if p.is_absolute() else R/p
 return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
new={
 'ENG-R1-005':{1,3,6,34,42},
 'ENG-R1-006':{1,20,37},
 'ENG-R1-007':{1,2,21,39},
}
peers=['code','security','ux']
refs=[ref(C/'reviews'/x/'report.md') for x in peers]
for s in d['specs']:
 i=int(s['spec_id'][-3:])
 for f,affected in new.items():
  if i in affected:
   s['finding_ids'].append(f);s['decision']='CHANGES_REQUIRED'
 s['supporting_evidence']+=refs
 if i in new['ENG-R1-005']:
  s['judgment']+=' Source-correlated CODE-R1-004: when first HR result arrives into an already mounted Result view, unchanged effect dependencies prevent admission, and manual refresh has no view token to recover.'
  s['exact_remaining_software_evidence_and_external_limits']+=' Repair/verify pending→HR same-ID/epoch transition and manual refresh without prior view token, retaining denial/mismatch/late callback fences.'
 if i in new['ENG-R1-006']:
  s['judgment']+=' Source-correlated SEC-02: returned OAuth result.url is not checked against the exact callback before code exchange, despite trusted outbound callback pins.'
  s['exact_remaining_software_evidence_and_external_limits']+=' Exact returned callback wrong-host/path/query/fragment refusal before token/capability traffic and valid exact native positives are required.'
 if i in new['ENG-R1-007']:
  s['judgment']+=' Source-correlated UX-R001: healthy connected_reader falls through to unavailable; Home hardcodes Synthetic-only/blanket qualified-unavailable wording, so installed conditional capabilities are misrepresented.'
  s['exact_remaining_software_evidence_and_external_limits']+=' Truthful physical connection/binding/channel-authority Home/Device agreement, including revoked/expired/unbound states; connection alone must not grant capture.'
for s in d['specs']:
 for path in ['apps/mobile/src/core/devicePresentation.ts','apps/mobile/src/ui/device-summary.tsx','apps/mobile/src/device/controller.ts','apps/mobile/src/ui/checks.tsx','apps/mobile/src/services/sync.ts','apps/mobile/src/services/auth.ts','services/api/otgd/report_revisions.py']:
  if s['spec_id']=='OTGD-001' or (path.startswith('apps/mobile/src/ui/checks') and int(s['spec_id'][-3:]) in new['ENG-R1-005']) or (path.endswith('auth.ts') and int(s['spec_id'][-3:]) in new['ENG-R1-006']) or ('device' in path and int(s['spec_id'][-3:]) in new['ENG-R1-007']):s['implementation_test_contract_bindings'][path]=ref(path)['sha256']
artifacts=['reports/unit.xml','reports/unit-coverage.json','reports/atdd.xml','reports/hosted-preview.xml','reports/components.xml','reports/performance.json','apps/mobile/reports/mobile-unit-coverage.json']
current=[ref(x) for x in artifacts]+[ref(C/'unit-stage-artifacts.json')]
for s in d['specs']:s['supporting_evidence']+=current
counts={}
for s in d['specs']:counts[s['decision']]=counts.get(s['decision'],0)+1
d['decision_counts']=counts;d['latest_observation_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();d['specialist_findings_source_correlated']={'ENG-R1-004':'CODE-R1-003','ENG-R1-005':'CODE-R1-004','ENG-R1-006':'SEC-02','ENG-R1-007':'UX-R001'}
d['current_stage_evidence']={'unit':'PASS stage only; raw XML suite header1737,1529 testcase elements plus208pytest subtests, failures/errors/skips0; backend coverage89.91773148958515%, mobile91.14059386693881%','atdd':'6 ordinary +2guest preview actual browser cases, no failures/errors/skips','components':'72cases,0failures/errors/skips','performance':json.loads((R/'reports/performance.json').read_text()),'aggregate':'NOT COMPLETE; PM requested intentional stop at PostgreSQL boundary for correction2; no crash or recovery increment inferred','artifacts':current}
p.write_text(json.dumps(d,indent=2)+'\n')
# Updated concise human all47 dispositions are generated from the actual decisions.
lines=['# Provisional independent engineering dispositions','',f"Candidate `{d['candidate_revision']}`, IMPLEMENTATION; {counts}; no PASS. All remain provisional pending applicable corrected-candidate evidence.",'','| Spec | Decision | Independent engineering judgment | Missing evidence / external limit |','|---|---|---|---|']
for s in d['specs']:lines.append(f"| {s['spec_id']} | {s['decision']} | {s['judgment']} | {s['exact_remaining_software_evidence_and_external_limits']} |")
(O/'per-spec-dispositions.md').write_text('\n'.join(lines)+'\n')
ins=json.loads((O/'inspection-evidence.json').read_text());ins['latest_stage_evidence']=d['current_stage_evidence'];ins['specialist_reports_source_correlated']=refs;(O/'inspection-evidence.json').write_text(json.dumps(ins,indent=2)+'\n')
print(counts)
